'use client'

import Link from 'next/link'
import { Phone, Eye, Clock, Gem, Diamond, Sparkles } from 'lucide-react'
import { useSupabaseProducts } from '@/hooks/useSupabaseProducts'
import { formatPrice } from '@/lib/priceUtils'

export default function FeaturedProducts() {
  const { products, loading } = useSupabaseProducts()
  const featuredProducts = products.filter(product => product.featured)

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Joias':
        return Gem
      case 'Relógios':
        return Clock
      case 'Óculos':
        return Eye
      case 'Semi-Joias':
        return Diamond
      default:
        return Gem
    }
  }

  return (
    <section className="py-8 md:py-16 lg:py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-3 sm:px-4 md:px-6 lg:px-8">
        <div className="text-center mb-8 md:mb-12 lg:mb-16">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-light text-gray-900 mb-3 md:mb-6 tracking-wide">
            Produtos em Destaque
          </h2>
          <div className="w-16 md:w-20 h-0.5 bg-gray-800 mx-auto mb-4 md:mb-8"></div>
          <p className="text-sm sm:text-base md:text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed font-light px-4">
            Itens cuidadosamente selecionados para você
          </p>
        </div>

        {featuredProducts.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Gem className="h-8 w-8 text-gray-400" />
            </div>
            <p className="text-gray-500 text-lg font-light">Nenhum produto em destaque cadastrado.</p>
            <p className="text-sm text-gray-400 mt-2">Adicione produtos e marque como &quot;em destaque&quot; no painel administrativo.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6 lg:gap-8">
            {featuredProducts.map((product) => {
              const IconComponent = getCategoryIcon(product.category)
              return (
                <Link
                  key={product.id}
                  href={`/produto/${product.id}`}
                  className="group block bg-white border border-gray-200 hover:border-gray-800 transition-all duration-300 overflow-hidden hover:shadow-lg hover:-translate-y-2 active:scale-95"
                >
                  <div className="relative">
                    <img src={product.image} alt={product.name} className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute top-4 left-4">
                      <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium text-gray-800 flex items-center space-x-1">
                        <IconComponent className="h-3.5 w-3.5" />
                        <span>{product.category}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="text-lg font-medium text-gray-900 mb-2 group-hover:text-gray-800 transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-4 font-light">{product.brand}</p>

                    <div className="mb-4">
                        {product.on_sale ? (
                          <div className="flex flex-col">
                            <div className="flex items-center space-x-2 mb-2">
                              <span className="text-sm text-gray-500 line-through">
                                {formatPrice(product.original_price || '')}
                              </span>
                              <span className="bg-gray-800 text-white text-xs px-2 py-1 rounded-full font-medium">
                                -{product.discount_percentage}%
                              </span>
                            </div>
                            <span className="text-xl font-medium text-gray-900">
                              {formatPrice(product.sale_price || '')}
                            </span>
                          </div>
                        ) : (
                          <span className="text-xl font-medium text-gray-900">{formatPrice(product.price)}</span>
                        )}
                    </div>
                  </div>
                </Link>
              )
            })}
          </div>
        )}

        {featuredProducts.length > 0 && (
          <div className="text-center mt-12">
            <Link
              href="/produtos"
              className="inline-flex items-center border border-gray-800 text-gray-800 hover:bg-gray-800 hover:text-white px-8 py-3 transition-all duration-300 font-medium hover:scale-105 active:scale-95"
            >
              Ver todos os produtos
              <svg className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
        )}
      </div>
    </section>
  )
}