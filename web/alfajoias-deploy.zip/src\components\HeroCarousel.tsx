'use client'

import { useState, useEffect } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

export default function HeroCarousel() {
  const [banners, setBanners] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const loadBanners = async () => {
      try {
        const { supabase } = await import('@/lib/supabase')
        console.log('🔄 Buscando banners do banco...')
        
        const { data, error } = await supabase
          .from('banners')
          .select('*')
          .eq('active', true)
          .order('created_at', { ascending: false })
        
        if (data && data.length > 0 && !error) {
          console.log('✅ Banners carregados do BANCO:', data.length)
          setBanners(data.map((b: any) => ({
            id: b.id,
            title: b.title,
            subtitle: b.subtitle,
            image: b.image,
            ctaText: b.cta_text,
            ctaLink: b.cta_link,
            active: b.active
          })))
          setLoading(false)
          return
        }
        
        console.warn('⚠️ Banco de banners vazio, usando banners padrão')
      } catch (err) {
        console.log('⚠️ Erro ao buscar banners, usando padrão')
      }
      
      // Fallback: banners padrão
      const defaultBanners = [
        {
          id: '1',
          title: 'Alfa Jóias',
          subtitle: 'A Vitrine dos seus Olhos',
          image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1200&h=800&fit=crop',
          ctaText: 'Explorar',
          ctaLink: '/produtos',
          active: true
        },
        {
          id: '2',
          title: 'Promoções Especiais',
          subtitle: 'Até 50% de desconto em produtos selecionados',
          image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=1200&h=800&fit=crop',
          ctaText: 'Ver Ofertas',
          ctaLink: '/promocoes',
          active: true
        }
      ]
      setBanners(defaultBanners)
      setLoading(false)
    }
    
    loadBanners()
  }, [])

  const activeBanners = banners.filter(b => b.active)

  useEffect(() => {
    if (activeBanners.length > 1) {
      const interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % activeBanners.length)
      }, 5000)
      return () => clearInterval(interval)
    }
  }, [activeBanners])

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % activeBanners.length)
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + activeBanners.length) % activeBanners.length)

  if (loading) {
    return (
      <section className="relative bg-white">
        <div className="relative h-[70vh] min-h-[500px] overflow-hidden">
          <div className="absolute inset-0 bg-gray-200 animate-pulse" />
          <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
            <div className="max-w-3xl">
              <div className="h-16 bg-gray-300 rounded mb-6 animate-pulse"></div>
              <div className="w-24 h-1 bg-gray-300 rounded mb-8 animate-pulse"></div>
              <div className="h-8 bg-gray-300 rounded mb-10 animate-pulse"></div>
              <div className="h-12 w-32 bg-gray-300 rounded animate-pulse"></div>
            </div>
          </div>
        </div>
      </section>
    )
  }

  if (activeBanners.length === 0) {
    return (
      <section className="relative bg-white">
        <div className="relative h-[70vh] min-h-[500px] overflow-hidden">
          <div className="absolute inset-0 bg-gray-200" />
          <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
            <div className="max-w-3xl">
              <h1 className="text-5xl md:text-7xl font-light tracking-wide text-gray-900 mb-6 leading-tight">
                Alfa Jóias
              </h1>
              <div className="w-24 h-0.5 bg-gray-800 mb-8"></div>
              <p className="text-xl md:text-2xl text-gray-700 mb-10 font-light leading-relaxed">
                A Vitrine dos seus Olhos
              </p>
              <a
                href="/produtos"
                className="inline-flex items-center border border-gray-800 text-gray-800 hover:bg-gray-800 hover:text-white px-8 py-4 transition-all duration-300 font-medium hover:scale-105 active:scale-95"
              >
                Explorar
                <svg className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="relative bg-white">
      <div className="relative h-[70vh] min-h-[500px] overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-1000 ease-in-out"
          style={{ backgroundImage: `url(${activeBanners[currentSlide]?.image})` }}
        />
        <div className="absolute inset-0 bg-black/30 transition-opacity duration-1000" />
        
        <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="max-w-3xl">
            <h1 className="text-5xl md:text-7xl font-light tracking-wide text-white mb-6 leading-tight transition-all duration-700 ease-in-out">
              {activeBanners[currentSlide]?.title}
            </h1>
            <div className="w-24 h-0.5 bg-white mb-8 transition-all duration-700 ease-in-out"></div>
            <p className="text-xl md:text-2xl text-white/90 mb-10 font-light leading-relaxed transition-all duration-700 ease-in-out">
              {activeBanners[currentSlide]?.subtitle}
            </p>
            <a
              href={activeBanners[currentSlide]?.ctaLink || '/produtos'}
              className="inline-flex items-center border border-white text-white hover:bg-white hover:text-gray-900 px-8 py-4 transition-all duration-300 font-medium hover:scale-105 active:scale-95"
            >
              {activeBanners[currentSlide]?.ctaText || 'Explorar'}
              <svg className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </a>
          </div>
        </div>

        {/* Navigation */}
        {activeBanners.length > 1 && (
          <>
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-2 rounded-full transition-all duration-300 backdrop-blur-sm"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white p-2 rounded-full transition-all duration-300 backdrop-blur-sm"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </>
        )}

        {/* Dots */}
        {activeBanners.length > 1 && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {activeBanners.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentSlide ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}