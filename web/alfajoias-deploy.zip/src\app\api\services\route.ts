import { NextResponse } from 'next/server'

export async function GET() {
  try {
    // Por enquanto, retornar dados do localStorage como fallback
    // Em produção, isso viria do Supabase
    const defaultServices = [
      {
        id: '1',
        title: 'Manutenção de Relógios',
        description: 'Reparos e ajustes em relógios de todas as marcas',
        features: ['Troca de bateria', 'Ajuste de pulseira', 'Limpeza interna'],
        whatsappMessage: 'Olá! Gostaria de solicitar informações sobre manutenção de relógios. Podem me ajudar?'
      },
      {
        id: '2',
        title: 'Ajustes de Óculos',
        description: 'Ajustes precisos para melhor conforto e visual',
        features: ['Ajuste de hastes', 'Correção de posição', 'Troca de lentes'],
        whatsappMessage: 'Olá! Gostaria de solicitar informações sobre ajustes de óculos. Podem me ajudar?'
      },
      {
        id: '3',
        title: 'Garantia Estendida',
        description: 'Garantia adicional em produtos e serviços',
        features: ['Garantia de 1 ano', 'Suporte técnico', 'Troca sem burocracia'],
        whatsappMessage: 'Olá! Gostaria de solicitar informações sobre garantia estendida. Podem me ajudar?'
      },
      {
        id: '4',
        title: 'Serviço Rápido',
        description: 'Atendimento ágil para suas necessidades urgentes',
        features: ['Entrega no mesmo dia', 'Orçamento imediato', 'Atendimento prioritário'],
        whatsappMessage: 'Olá! Gostaria de solicitar informações sobre serviço rápido. Podem me ajudar?'
      },
      {
        id: '5',
        title: 'Qualidade Garantida',
        description: 'Produtos e serviços com certificação de qualidade',
        features: ['Produtos originais', 'Técnicos especializados', 'Materiais premium'],
        whatsappMessage: 'Olá! Gostaria de solicitar informações sobre qualidade garantida. Podem me ajudar?'
      },
      {
        id: '6',
        title: 'Troca de Bateria',
        description: 'Troca de bateria para relógios e acessórios',
        features: ['Baterias originais', 'Instalação gratuita', 'Garantia de 6 meses'],
        whatsappMessage: 'Olá! Gostaria de solicitar informações sobre troca de bateria. Podem me ajudar?'
      }
    ]

    return NextResponse.json({
      success: true,
      services: defaultServices
    })

  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { title, description, features, whatsappMessage } = body

    // Em produção, salvar no Supabase
    // Por enquanto, retornar sucesso
    return NextResponse.json({
      success: true,
      message: 'Serviço adicionado com sucesso',
      service: {
        id: Date.now().toString(),
        title,
        description,
        features,
        whatsappMessage
      }
    })

  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    }, { status: 500 })
  }
}




