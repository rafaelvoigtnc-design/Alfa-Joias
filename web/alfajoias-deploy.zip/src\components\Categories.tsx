'use client'

import Link from 'next/link'
import { Gem, Clock, Eye, Sparkles, Diamond, Wrench } from 'lucide-react'
import { useState, useEffect } from 'react'
import OptimizedImage from './OptimizedImage'

interface CategoryData {
  id: string
  name: string
  description: string
  image: string
  iconName: string
  href: string
}

export default function Categories() {
  const [categories, setCategories] = useState<CategoryData[]>([])
  const [loading, setLoading] = useState(false)

  const getDefaultCategory = (name: string): CategoryData | null => {
    const defaults = {
      'Joias': {
        id: '1',
        name: 'Joias',
        description: 'Anéis, colares, brincos e pulseiras em ouro e prata',
        iconName: 'gem',
        image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&h=600&fit=crop',
        href: '/produtos?categoria=Joias'
      },
      'Relógios': {
        id: '2',
        name: 'Relógios',
        description: 'Relógios masculinos e femininos das melhores marcas',
        iconName: 'clock',
        image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&h=600&fit=crop',
        href: '/produtos?categoria=Relógios'
      },
      'Óculos': {
        id: '3',
        name: 'Óculos',
        description: 'Óculos de sol e grau com tecnologia avançada',
        iconName: 'eye',
        image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&h=600&fit=crop',
        href: '/produtos?categoria=Óculos'
      },
      'Semi-Joias': {
        id: '4',
        name: 'Semi-Joias',
        description: 'Bijuterias elegantes e acessórios modernos',
        iconName: 'diamond',
        image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&h=600&fit=crop',
        href: '/produtos?categoria=Semi-Joias'
      }
    }
    return defaults[name as keyof typeof defaults] || null
  }

  useEffect(() => {
    const loadCategories = async () => {
      try {
        // SEMPRE carregar do Supabase
        const { supabase } = await import('@/lib/supabase')
        console.log('🔄 Buscando categorias do banco...')
        
        const { data, error } = await supabase
          .from('categories')
          .select('*')
          .order('created_at', { ascending: false })
        
        if (data && data.length > 0 && !error) {
          console.log('✅ Categorias carregadas do BANCO:', data.length)
          
          // Filtrar apenas as 4 categorias corretas
          const validCategories = ['Joias', 'Relógios', 'Óculos', 'Semi-Joias']
          const filteredData = data.filter((cat: any) => validCategories.includes(cat.name))
          
          // Mapear categorias do banco para o formato do componente
          const mappedCategories = filteredData.map((cat: any) => ({
            id: cat.id,
            name: cat.name,
            description: cat.description,
            image: cat.image,
            iconName: cat.icon || 'gem',
            href: `/produtos?categoria=${cat.name}`
          }))
          
          // Garantir que temos as 4 categorias (adicionar as que faltam)
          const finalCategories = []
          const categoryMap = new Map(mappedCategories.map(cat => [cat.name, cat]))
          
          // Adicionar categorias na ordem correta
          validCategories.forEach(name => {
            if (categoryMap.has(name)) {
              finalCategories.push(categoryMap.get(name)!)
            } else {
              // Adicionar categoria padrão se não existir no banco
              const defaultCat = getDefaultCategory(name)
              if (defaultCat) finalCategories.push(defaultCat)
            }
          })
          
          // Adicionar item "Serviços" sempre por último
          finalCategories.push({
            id: 'services',
            name: 'Serviços',
            description: 'Manutenção, reparos e serviços especializados',
            iconName: 'wrench',
            image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=600&fit=crop',
            href: '/servicos'
          })
          
          setCategories(finalCategories)
          setLoading(false)
          return
        }
        
        console.warn('⚠️ Banco de categorias vazio, usando categorias padrão...')
      } catch (err) {
        console.log('⚠️ Erro ao buscar categorias, usando padrão')
      }
      
      // Fallback: 4 categorias + 1 serviço
      const defaultCategories: CategoryData[] = [
        {
          id: '1',
          name: 'Joias',
          description: 'Anéis, colares, brincos e pulseiras em ouro e prata',
          iconName: 'gem',
          image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&h=600&fit=crop',
          href: '/produtos?categoria=Joias'
        },
        {
          id: '2',
          name: 'Relógios',
          description: 'Relógios masculinos e femininos das melhores marcas',
          iconName: 'clock',
          image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&h=600&fit=crop',
          href: '/produtos?categoria=Relógios'
        },
        {
          id: '3',
          name: 'Óculos',
          description: 'Óculos de sol e grau com tecnologia avançada',
          iconName: 'eye',
          image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&h=600&fit=crop',
          href: '/produtos?categoria=Óculos'
        },
        {
          id: '4',
          name: 'Semi-Joias',
          description: 'Bijuterias elegantes e acessórios modernos',
          iconName: 'diamond',
          image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&h=600&fit=crop',
          href: '/produtos?categoria=Semi-Joias'
        },
        {
          id: '5',
          name: 'Serviços',
          description: 'Manutenção, reparos e serviços especializados',
          iconName: 'sparkles',
          image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=600&fit=crop',
          href: '/servicos'
        }
      ]
      
      setCategories(defaultCategories)
      setLoading(false)
    }
    
    loadCategories()
  }, [])

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'gem':
        return Gem
      case 'clock':
        return Clock
      case 'eye':
        return Eye
      case 'diamond':
        return Diamond
      case 'sparkles':
        return Sparkles
      case 'wrench':
        return Wrench
      default:
        return Gem
    }
  }

  if (loading) {
    return (
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-light text-gray-900 mb-6 tracking-wide">
              Nossas Especialidades
            </h2>
            <div className="w-20 h-0.5 bg-gray-800 mx-auto mb-8"></div>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed font-light">
              Carregando categorias...
            </p>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-8 md:py-16 lg:py-20 bg-white">
      <div className="max-w-6xl mx-auto px-3 sm:px-4 md:px-6 lg:px-8">
        <div className="text-center mb-8 md:mb-12 lg:mb-16">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-light text-gray-900 mb-3 md:mb-6 tracking-wide">
            Nossas Especialidades
          </h2>
          <div className="w-16 md:w-20 h-0.5 bg-gray-800 mx-auto mb-4 md:mb-8"></div>
          <p className="text-sm sm:text-base md:text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed font-light px-4">
            Descubra nossa seleção cuidadosamente curada de produtos e serviços
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-3 sm:gap-4 md:gap-6 max-w-7xl mx-auto">
          {categories.map((category, index) => {
            const IconComponent = getIconComponent(category.iconName)
            // Garantir que href existe
            const href = category.href || '/produtos'
            return (
              <Link
                key={category.id}
                href={href}
                className="group block bg-white border border-gray-200 hover:border-gray-800 transition-all duration-300 overflow-hidden hover:shadow-lg hover:-translate-y-2 active:scale-95 w-[calc(50%-0.375rem)] sm:w-[calc(33.333%-0.667rem)] md:w-[calc(25%-1.125rem)] lg:w-[calc(20%-1.2rem)] flex-shrink-0"
              >
                <div className="relative h-24 sm:h-32 md:h-36 lg:h-40 overflow-hidden">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none'
                    }}
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors duration-300" />

                  <div className="absolute top-1.5 sm:top-2 right-1.5 sm:right-2">
                    <div className="bg-white/90 backdrop-blur-sm text-gray-800 p-1 sm:p-1.5 rounded-full shadow-sm group-hover:bg-gray-800 group-hover:text-white transition-all duration-300">
                      <IconComponent className="h-2.5 w-2.5 sm:h-3 sm:w-3" />
                    </div>
                  </div>
                </div>

                <div className="p-2 sm:p-2.5 md:p-3">
                  <h3 className="text-xs sm:text-sm md:text-base font-medium text-gray-900 mb-0.5 sm:mb-1 group-hover:text-gray-800 transition-colors">
                    {category.name}
                  </h3>
                  <p className="text-gray-600 text-[10px] sm:text-xs leading-tight sm:leading-relaxed line-clamp-2">
                    {category.description}
                  </p>
                </div>
              </Link>
            )
          })}
        </div>
      </div>
    </section>
  )
}