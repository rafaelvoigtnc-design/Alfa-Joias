import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import { UnifiedAuthProvider } from '@/contexts/UnifiedAuthContext'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import '@/lib/autoPriceCleaner'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: {
    default: 'Alfa Jóias - A Vitrine dos seus Olhos',
    template: '%s | Alfa Jóias'
  },
  description: 'Ótica, Relojoaria e Joalheria em Nova Candelária-RS. Óculos, relógios, joias e semi-joias das melhores marcas. Atendimento personalizado via WhatsApp.',
  keywords: ['ótica', 'relojoaria', 'joalheria', 'óculos', 'relógios', 'joias', 'semi-joias', 'Nova Candelária', 'RS', 'ouro', 'prata', 'diamante', 'Ray-Ban', 'Oakley', 'Rolex', 'Cartier'],
  authors: [{ name: 'Alfa Jóias', url: 'https://alfajoias.com.br' }],
  creator: 'Alfa Jóias',
  publisher: 'Alfa Jóias',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  icons: {
    icon: '/favicon.svg',
    shortcut: '/favicon.ico',
    apple: '/favicon.ico',
  },
  manifest: '/manifest.json',
  openGraph: {
    title: 'Alfa Jóias - A Vitrine dos seus Olhos',
    description: 'Joias, relógios, óculos e semi-joias das melhores marcas em Nova Candelária-RS',
    url: 'https://alfajoias.com.br',
    siteName: 'Alfa Jóias',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Alfa Jóias - Joalheria, Relojoaria e Ótica',
      }
    ],
    locale: 'pt_BR',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Alfa Jóias - A Vitrine dos seus Olhos',
    description: 'Joias, relógios e óculos das melhores marcas',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  category: 'shopping',
}

export const viewport = {
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="dns-prefetch" href="https://images.unsplash.com" />
      </head>
      <body className={inter.className}>
        <UnifiedAuthProvider>
          <Header />
          <main className="min-h-screen">
            {children}
          </main>
          <Footer />
        </UnifiedAuthProvider>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" async></script>
      </body>
    </html>
  )
}
