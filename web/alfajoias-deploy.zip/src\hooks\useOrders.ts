import { useState, useEffect } from 'react'
import { supabase, Order } from '@/lib/supabase'

export function useOrders() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchOrders = async () => {
    try {
      setLoading(true)
      setError(null)
      
      console.log('🔄 Carregando pedidos do Supabase...')
      
      // Carregar pedidos do Supabase
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) {
        console.error('❌ Erro ao carregar pedidos do Supabase:', error)
        setError(error.message)
        setOrders([])
        return
      }
      
      console.log('✅ Pedidos carregados do Supabase:', data?.length || 0)
      console.log('📦 Pedidos do Supabase:', data)
      
      setOrders(data || [])
    } catch (err) {
      console.error('❌ Erro geral ao carregar pedidos:', err)
      setError(err instanceof Error ? err.message : 'Erro ao carregar pedidos')
      setOrders([])
    } finally {
      setLoading(false)
    }
  }

  const updateOrderStatus = async (orderId: string, status: string) => {
    try {
      const updates: any = { 
        status,
        updated_at: new Date().toISOString()
      }

      if (status === 'shipped') {
        updates.shipped_at = new Date().toISOString()
      } else if (status === 'delivered') {
        updates.delivered_at = new Date().toISOString()
      }

      // Atualizar no Supabase
      const { data, error } = await supabase
        .from('orders')
        .update(updates)
        .eq('id', orderId)
        .select()
        .single()

      if (error) throw error

      // Atualizar lista local
      setOrders(prev => prev.map(order => 
        order.id === orderId ? { ...order, ...updates } : order
      ))
      
      return { data: updates, error: null }
    } catch (err) {
      console.error('Erro ao atualizar status do pedido:', err)
      return { data: null, error: err }
    }
  }

  const addTrackingNumber = async (orderId: string, trackingNumber: string) => {
    try {
      const updates = { 
        tracking_number: trackingNumber,
        updated_at: new Date().toISOString()
      }

      // Atualizar no Supabase
      const { data, error } = await supabase
        .from('orders')
        .update(updates)
        .eq('id', orderId)
        .select()
        .single()

      if (error) throw error

      // Atualizar lista local
      setOrders(prev => prev.map(order => 
        order.id === orderId ? { ...order, ...updates } : order
      ))
      
      return { data: updates, error: null }
    } catch (err) {
      console.error('Erro ao adicionar número de rastreamento:', err)
      return { data: null, error: err }
    }
  }

  useEffect(() => {
    fetchOrders()
  }, [])

  return {
    orders,
    loading,
    error,
    updateOrderStatus,
    addTrackingNumber,
    refetch: fetchOrders
  }
}
