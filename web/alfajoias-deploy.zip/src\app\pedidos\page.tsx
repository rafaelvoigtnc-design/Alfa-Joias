'use client'

import { useUnifiedAuth } from '@/contexts/UnifiedAuthContext'
import { Package, Calendar, Phone, CheckCircle, Clock } from 'lucide-react'

export default function Orders() {
  const { user } = useUnifiedAuth()

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Faça login para acessar seus pedidos</h1>
          <p className="text-gray-600 mb-6">Você precisa estar logado para acessar esta página.</p>
          <a
            href="/login"
            className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
          >
            Fazer Login
          </a>
        </div>
      </div>
    )
  }

  // Mock de pedidos
  const orders = [
    {
      id: 'PED-001',
      date: '2024-01-15',
      status: 'Entregue',
      items: [
        { name: 'Óculos de Sol Ray-Ban', quantity: 1, price: 'R$ 299,00' },
        { name: 'Relógio Casio Digital', quantity: 1, price: 'R$ 89,00' }
      ],
      total: 'R$ 388,00'
    },
    {
      id: 'PED-002',
      date: '2024-01-20',
      status: 'Em trânsito',
      items: [
        { name: 'Anel de Prata 925', quantity: 2, price: 'R$ 149,00' }
      ],
      total: 'R$ 298,00'
    }
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Entregue':
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case 'Em trânsito':
        return <Clock className="h-5 w-5 text-yellow-500" />
      default:
        return <Clock className="h-5 w-5 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Entregue':
        return 'text-green-600 bg-green-100'
      case 'Em trânsito':
        return 'text-yellow-600 bg-yellow-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Meus Pedidos</h1>

        {orders.length === 0 ? (
          <div className="text-center py-12">
            <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Nenhum pedido encontrado</h2>
            <p className="text-gray-600 mb-6">Você ainda não fez nenhum pedido.</p>
            <a
              href="/produtos"
              className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Ver Produtos
            </a>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map((order) => (
              <div key={order.id} className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Pedido {order.id}</h3>
                    <p className="text-sm text-gray-600 flex items-center mt-1">
                      <Calendar className="h-4 w-4 mr-2" />
                      {new Date(order.date).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(order.status)}
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.status)}`}>
                      {order.status}
                    </span>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium text-gray-900 mb-3">Itens do pedido:</h4>
                  <div className="space-y-2 mb-4">
                    {order.items.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span>{item.name} x{item.quantity}</span>
                        <span className="font-medium">{item.price}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between border-t pt-3">
                    <span className="text-lg font-semibold text-gray-900">Total:</span>
                    <span className="text-lg font-bold text-gray-600">{order.total}</span>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t">
                  <a
                    href={`https://wa.me/5555991288464?text=${encodeURIComponent(`Olá! Gostaria de falar sobre meu pedido ${order.id} na Alfa Jóias.

Podem me ajudar com informações sobre o status do pedido?`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-2 text-gray-600 hover:text-gray-800 transition-colors"
                  >
                    <Phone className="h-4 w-4" />
                    <span>Falar sobre este pedido</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

