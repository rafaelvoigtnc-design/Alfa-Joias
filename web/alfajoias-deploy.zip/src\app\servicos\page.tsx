'use client'

import { Wrench, Battery, Settings, Shield, Clock, Award, Phone, MessageCircle } from 'lucide-react'
import { useSupabaseServices } from '@/hooks/useSupabaseServices'

export default function Servicos() {
  const { services, loading } = useSupabaseServices()
  
  const getServiceIcon = (title: string) => {
    if (title.toLowerCase().includes('manutenção')) return Wrench
    if (title.toLowerCase().includes('ajuste')) return Settings
    if (title.toLowerCase().includes('bateria')) return Battery
    if (title.toLowerCase().includes('garantia')) return Shield
    if (title.toLowerCase().includes('rápido')) return Clock
    if (title.toLowerCase().includes('qualidade')) return Award
    return Wrench
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Nossos Serviços
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Oferecemos serviços especializados para manter seus produtos sempre em perfeito estado
          </p>
        </div>

        {/* Loading */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-800 mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando serviços do banco...</p>
          </div>
        ) : services.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Wrench className="h-8 w-8 text-gray-400" />
            </div>
            <p className="text-gray-500 text-lg">Nenhum serviço cadastrado no banco.</p>
            <p className="text-sm text-gray-400 mt-2">Adicione serviços pelo painel administrativo.</p>
          </div>
        ) : (
          <>
            {/* Services Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
              {services.map((service, index) => {
                const IconComponent = getServiceIcon(service.title)
                return (
                <div
                  key={service.id}
                  className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 p-8"
                >
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <IconComponent className="h-8 w-8 text-gray-600" />
                  </div>
                  
                  <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                    {service.title}
                  </h3>
                  
                  <p className="text-gray-600 mb-6 text-center">
                    {service.description}
                  </p>

                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-3">Inclui:</h4>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center space-x-2 text-sm text-gray-600">
                          <div className="w-2 h-2 bg-gray-800 rounded-full"></div>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="text-center">
                    <a
                      href={`https://wa.me/5555991288464?text=${encodeURIComponent(service.whatsapp_message)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-gray-800 hover:bg-gray-900 text-white px-6 py-3 rounded-full font-medium transition-colors flex items-center justify-center space-x-2"
                    >
                      <MessageCircle className="h-4 w-4" />
                      <span>Solicitar Orçamento</span>
                    </a>
                  </div>
                </div>
              )
            })}
          </div>
          </>
        )}

        {/* Process Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-16">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">
            Como Funciona
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-gray-600">1</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Entre em Contato
              </h3>
              <p className="text-gray-600">
                Fale conosco via WhatsApp ou telefone para solicitar o serviço
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-gray-600">2</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Orçamento Gratuito
              </h3>
              <p className="text-gray-600">
                Avaliamos seu produto e fornecemos um orçamento sem compromisso
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-gray-600">3</span>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Execução e Entrega
              </h3>
              <p className="text-gray-600">
                Realizamos o serviço com qualidade e entregamos no prazo combinado
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-gray-800 to-gray-900 text-white rounded-xl p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">
            Precisa de um Serviço Específico?
          </h3>
          <p className="text-lg mb-6">
            Entre em contato conosco e solicite um orçamento personalizado
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <a
              href="https://wa.me/5555991288464"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white text-gray-600 hover:bg-gray-100 px-8 py-3 rounded-full font-semibold text-lg transition-colors inline-flex items-center space-x-2"
            >
              <MessageCircle className="h-5 w-5" />
              <span>WhatsApp</span>
            </a>
            <a
              href="tel:+5555991288464"
              className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-gray-600 px-8 py-3 rounded-full font-semibold text-lg transition-colors inline-flex items-center space-x-2"
            >
              <Phone className="h-5 w-5" />
              <span>Ligar</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
