'use client'

import Link from 'next/link'
import { Phone, Percent, Clock, Gem, Diamond, Sparkles, Eye } from 'lucide-react'
import { useProducts } from '@/hooks/useProducts'

export default function Promotions() {
  const { getProductsOnSale, loading } = useProducts()
  const products = getProductsOnSale()

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Joias':
        return Gem
      case 'Relógios':
        return Clock
      case 'Óculos':
        return Eye
      case 'Semi-Joias':
        return Diamond
      default:
        return Gem
    }
  }

  // Sempre mostrar a seção, mesmo se não houver produtos

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-light text-gray-900 mb-6 tracking-wide">
            Promoções Especiais
          </h2>
          <div className="w-20 h-0.5 bg-gray-800 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed font-light">
            Aproveite nossas ofertas por tempo limitado
          </p>
        </div>

        {products.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Percent className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">Nenhuma promoção ativa</h3>
            <p className="text-gray-600 mb-6">Fique atento às nossas ofertas especiais!</p>
            <a
              href="https://wa.me/5555991288464"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center border border-gray-800 text-gray-800 hover:bg-gray-800 hover:text-white px-6 py-3 transition-all duration-300 font-medium hover:scale-105 active:scale-95"
            >
              <Phone className="h-4 w-4 mr-2" />
              Falar no WhatsApp
            </a>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product, index) => {
              const IconComponent = getCategoryIcon(product.category)
              return (
                <Link
                  key={product.id}
                  href={`/produto/${product.id}`}
                  className="group block bg-white border border-gray-200 hover:border-gray-800 transition-all duration-300 overflow-hidden hover:shadow-lg hover:-translate-y-2 active:scale-95"
                  style={{ animationDelay: `${index * 200}ms` }}
                >
                  <div className="relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-4 left-4">
                      <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium text-gray-800 flex items-center space-x-1">
                        <IconComponent className="h-3.5 w-3.5" />
                        <span>{product.category}</span>
                      </div>
                    </div>
                    <div className="absolute top-4 right-4">
                      <div className="bg-red-600 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center space-x-1 shadow-lg">
                        <Percent className="h-3.5 w-3.5" />
                        <span>{product.discount_percentage}% OFF</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-medium text-gray-900 mb-2 group-hover:text-gray-800 transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-4 font-light">{product.brand}</p>

                    <div className="mb-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-sm text-gray-500 line-through">
                          {product.original_price}
                        </span>
                        <span className="bg-red-100 text-red-600 px-2 py-1 rounded text-xs font-bold">
                          -{product.discount_percentage}%
                        </span>
                      </div>
                      <span className="text-2xl font-bold text-red-600">
                        {product.sale_price}
                      </span>
                    </div>

                    <a
                      href={`https://wa.me/5555991288464?text=${encodeURIComponent(`Olá! Tenho interesse na promoção: ${product.name} - ${product.sale_price} (${product.discount_percentage}% de desconto)

Podem me ajudar com esta oferta?`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full border border-gray-800 text-gray-800 hover:bg-gray-800 hover:text-white px-6 py-3 transition-all duration-300 flex items-center justify-center space-x-2 font-medium hover:scale-105 active:scale-95"
                    >
                      <Phone className="h-4 w-4 transition-transform duration-300 group-hover:scale-110" />
                      <span>Aproveitar Oferta</span>
                    </a>
                  </div>
                </Link>
              )
            })}
          </div>
        )}
      </div>
    </section>
  )
}