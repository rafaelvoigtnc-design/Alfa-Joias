'use client'

import { useState, useEffect } from 'react'
import { useBrands } from '@/hooks/useBrands'

export default function Brands() {
  const { brands, loading } = useBrands()
  // Removido filtro por 'active' - coluna não existe no banco
  const activeBrands = brands
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoRotating, setIsAutoRotating] = useState(false)

  // Verificar se precisa de rotação (mais de 6 marcas)
  const needsRotation = activeBrands.length > 6

  // Iniciar rotação automaticamente quando necessário
  useEffect(() => {
    if (needsRotation && activeBrands.length > 0) {
      setIsAutoRotating(true)
    }
  }, [needsRotation, activeBrands.length])

  useEffect(() => {
    if (needsRotation && activeBrands.length > 0 && isAutoRotating) {
      const interval = setInterval(() => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % activeBrands.length)
      }, 15000) // 15 segundos

      return () => clearInterval(interval)
    }
  }, [needsRotation, activeBrands.length, isAutoRotating])

  // Pausar rotação ao passar o mouse
  const handleMouseEnter = () => {
    if (needsRotation) {
      setIsAutoRotating(false)
    }
  }

  const handleMouseLeave = () => {
    if (needsRotation) {
      setIsAutoRotating(true)
    }
  }

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Marcas que Trabalhamos
          </h2>
          <p className="text-gray-600">
            Parcerias com as melhores marcas do mercado
          </p>
        </div>

        {activeBrands.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">Nenhuma marca cadastrada ainda.</p>
            <p className="text-sm text-gray-400 mt-2">Adicione marcas no painel administrativo.</p>
          </div>
        ) : (
          <div 
            className="relative overflow-hidden"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            {needsRotation ? (
              <div className="flex transition-transform duration-1000 ease-in-out"
                   style={{ transform: `translateX(-${currentIndex * (100 / 6)}%)` }}>
                {activeBrands.map((brand) => (
                  <div
                    key={brand.id}
                    className="flex-shrink-0 w-1/6 px-3"
                  >
                    <div className="bg-white rounded-lg p-6 text-center hover:bg-gray-50 transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                      <div className="mb-3">
                        <img 
                          src={brand.image} 
                          alt={brand.name}
                          className="w-16 h-16 object-contain mx-auto rounded-lg"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none'
                          }}
                        />
                      </div>
                      <div className="text-sm font-medium text-gray-700">
                        {brand.name}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
                {activeBrands.map((brand) => (
                  <div
                    key={brand.id}
                    className="bg-white rounded-lg p-6 text-center hover:bg-gray-50 transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
                  >
                    <div className="mb-3">
                      <img 
                        src={brand.image} 
                        alt={brand.name}
                        className="w-16 h-16 object-contain mx-auto rounded-lg"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none'
                        }}
                      />
                    </div>
                    <div className="text-sm font-medium text-gray-700">
                      {brand.name}
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Indicadores de posição */}
            {needsRotation && (
              <div className="flex justify-center mt-4 space-x-2">
                {activeBrands.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2 h-2 rounded-full transition-colors duration-300 ${
                      index === currentIndex ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  )
}
