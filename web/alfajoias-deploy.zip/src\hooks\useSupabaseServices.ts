import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'

interface Service {
  id: string
  title: string
  description: string
  features: string[]
  whatsapp_message: string
  created_at: string
  updated_at: string
}

export function useSupabaseServices() {
  const [services, setServices] = useState<Service[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadServices()
  }, [])

  const loadServices = async () => {
    try {
      setLoading(true)
      console.log('🔄 Buscando serviços do banco...')
      
      const { data, error } = await supabase
        .from('services')
        .select('*')
        .order('created_at', { ascending: true })

      if (error) {
        console.error('❌ Erro ao buscar serviços do banco:', error.message)
        setServices([])
        setLoading(false)
        return
      }
      
      if (!data || data.length === 0) {
        console.warn('⚠️ Banco de serviços está vazio!')
        setServices([])
        setLoading(false)
        return
      }
      
      console.log('✅ Serviços carregados do BANCO:', data.length)
      setServices(data)
      setLoading(false)
    } catch (error) {
      console.error('❌ Erro ao carregar serviços:', error)
      setServices([])
      setLoading(false)
    }
  }

  const addService = async (service: Omit<Service, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      console.log('➕ Adicionando serviço no banco...')
      
      const { data, error } = await supabase
        .from('services')
        .insert([{
          title: service.title,
          description: service.description,
          features: service.features,
          whatsapp_message: service.whatsapp_message
        }])
        .select()
        .single()

      if (error) {
        console.error('❌ Erro ao adicionar serviço:', error)
        throw error
      }

      console.log('✅ Serviço adicionado ao banco')
      setServices(prev => [...prev, data])
      return data
    } catch (error) {
      console.error('❌ Erro ao adicionar serviço:', error)
      throw error
    }
  }

  const updateService = async (id: string, updates: Partial<Service>) => {
    try {
      console.log('✏️ Atualizando serviço no banco...')
      
      const { data, error } = await supabase
        .from('services')
        .update(updates)
        .eq('id', id)
        .select()
        .single()

      if (error) {
        console.error('❌ Erro ao atualizar serviço:', error)
        throw error
      }

      console.log('✅ Serviço atualizado no banco')
      setServices(prev => prev.map(service => 
        service.id === id ? data : service
      ))
      return data
    } catch (error) {
      console.error('❌ Erro ao atualizar serviço:', error)
      throw error
    }
  }

  const deleteService = async (id: string) => {
    try {
      console.log('🗑️ Deletando serviço do banco...')
      
      const { error } = await supabase
        .from('services')
        .delete()
        .eq('id', id)

      if (error) {
        console.error('❌ Erro ao deletar serviço:', error)
        throw error
      }

      console.log('✅ Serviço deletado do banco')
      setServices(prev => prev.filter(service => service.id !== id))
    } catch (error) {
      console.error('❌ Erro ao deletar serviço:', error)
      throw error
    }
  }

  return {
    services,
    loading,
    addService,
    updateService,
    deleteService,
    refresh: loadServices
  }
}
