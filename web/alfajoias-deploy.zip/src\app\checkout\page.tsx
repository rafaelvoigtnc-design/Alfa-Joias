'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ShoppingCart, MessageCircle, User, Package } from 'lucide-react'
import { useUnifiedAuth } from '@/contexts/UnifiedAuthContext'
import { supabase } from '@/lib/supabase'
import { logger } from '@/lib/logger'

export default function Checkout() {
  const { cart, clearCart, user } = useUnifiedAuth()
  const router = useRouter()
  
  const [formData, setFormData] = useState({
    name: user?.user_metadata?.full_name || user?.user_metadata?.name || user?.email?.split('@')[0] || '',
    phone: user?.user_metadata?.phone || '',
    notes: ''
  })
  
  const [loading, setLoading] = useState(false)

  // Função para formatar preço para exibição (sempre vírgula para decimais)
  const formatPriceForDisplay = (price: string | number): string => {
    if (typeof price === 'number') {
      return price.toFixed(2).replace('.', ',')
    }
    // Limpar caracteres especiais e converter vírgula para ponto
    const cleaned = price.toString().replace(/[^\d.,]/g, '').replace(',', '.')
    const num = parseFloat(cleaned)
    if (isNaN(num)) return '0,00'
    return num.toFixed(2).replace('.', ',')
  }

  const calculateTotal = () => {
    return cart.reduce((total, item) => {
      const priceToUse = item.on_sale && item.sale_price ? item.sale_price : item.price
      const priceStr = typeof priceToUse === 'string' ? priceToUse : String(priceToUse)
      const price = parseFloat(priceStr.replace(/[^\d.,]/g, '').replace(',', '.'))
      return total + (isNaN(price) ? 0 : price * item.quantity)
    }, 0)
  }

  const calculateSubtotal = () => {
    return cart.reduce((total, item) => {
      const priceToUse = item.on_sale && item.sale_price ? item.sale_price : item.price
      const priceStr = typeof priceToUse === 'string' ? priceToUse : String(priceToUse)
      const price = parseFloat(priceStr.replace(/[^\d.,]/g, '').replace(',', '.'))
      return total + (isNaN(price) ? 0 : price * item.quantity)
    }, 0)
  }

  const generateOrderNumber = () => {
    const date = new Date()
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0')
    return `ALFA-${year}${month}${day}-${random}`
  }

  const formatWhatsAppMessage = () => {
    const orderNumber = generateOrderNumber()
    const total = calculateTotal()
    
    // Função de sanitização para WhatsApp
    const sanitize = (text: string): string => {
      return text
        .replace(/[<>]/g, '')
        .replace(/javascript:/gi, '')
        .replace(/\*/g, '＊')
        .replace(/_/g, '＿')
        .trim()
    }
    
    let message = `*NOVO PEDIDO - Alfa Joias*%0A%0A`
    message += `Pedido: ${orderNumber}%0A`
    message += `Data: ${new Date().toLocaleDateString('pt-BR')} as ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}%0A%0A`
    
    message += `*Cliente:* ${sanitize(formData.name)}%0A`
    message += `*Telefone:* ${sanitize(formData.phone)}%0A%0A`
    
    message += `*PRODUTOS:*%0A`
    cart.forEach((item, index) => {
      const priceToUse = item.on_sale && item.sale_price ? item.sale_price : item.price
      const priceStr = typeof priceToUse === 'string' ? priceToUse : String(priceToUse)
      const itemPrice = parseFloat(priceStr.replace(/[^\d.,]/g, '').replace(',', '.'))
      const subtotal = isNaN(itemPrice) ? 0 : itemPrice * item.quantity
      
      message += `${index + 1}. ${sanitize(item.name)}%0A`
      
      // Se estiver em promoção, mostrar preço original riscado
      if (item.on_sale && item.sale_price && item.original_price) {
        const origPriceStr = typeof item.original_price === 'string' ? item.original_price : String(item.original_price)
        const originalPrice = parseFloat(origPriceStr.replace(/[^\d.,]/g, '').replace(',', '.'))
        if (!isNaN(originalPrice)) {
          message += `   ~R$ ${formatPriceForDisplay(originalPrice)}~ `
          message += `*R$ ${formatPriceForDisplay(itemPrice)}*`
          if (item.discount_percentage) {
            message += ` (-${item.discount_percentage}%%)`
          }
          message += `%0A`
          message += `   ${item.quantity}x = R$ ${formatPriceForDisplay(subtotal)}%0A`
        }
      } else {
        message += `   ${item.quantity}x R$ ${formatPriceForDisplay(itemPrice)} = R$ ${formatPriceForDisplay(subtotal)}%0A`
      }
    })
    
    message += `%0A*TOTAL:* R$ ${formatPriceForDisplay(total)}%0A`
    
    if (formData.notes) {
      message += `%0A*Observacoes:* ${sanitize(formData.notes)}%0A`
    }
    
    message += `%0AGostaria de confirmar a disponibilidade e combinar a forma de pagamento e entrega. Obrigado!`
    
    return message
  }

  const handleWhatsAppSubmit = async () => {
    if (!formData.name || !formData.phone) {
      alert('Por favor, preencha seu nome e telefone')
      return
    }
    
    setLoading(true)
    
    try {
      const orderNumber = generateOrderNumber()
      const total = calculateTotal()
      
      // Salvar pedido no banco (campos mínimos essenciais)
      const orderData = {
        order_number: orderNumber,
        customer_name: formData.name,
        customer_phone: formData.phone,
        customer_email: user?.email || null,
        notes: formData.notes || null,
        products: cart.map(item => ({
          id: item.id,
          name: item.name,
          image: item.image || null,
          price: item.on_sale && item.sale_price ? item.sale_price : item.price,
          quantity: item.quantity
        })),
        subtotal: parseFloat(total.toFixed(2)),
        total: parseFloat(total.toFixed(2)),
        status: 'pending'
      }
      
      // Tentar salvar no banco
      logger.debug('Tentando salvar pedido no banco', {
        orderNumber,
        user_id: user?.id || 'não autenticado',
        total,
        productsCount: cart.length
      })
      
      const { data: insertedOrder, error: orderError } = await supabase
        .from('orders')
        .insert([orderData])
        .select()
      
      if (orderError) {
        logger.error('ERRO ao salvar pedido no banco', {
          message: orderError.message,
          code: orderError.code
        })
        
        // Tentar salvar com campos ainda mais básicos
        logger.debug('Tentando salvar com campos mínimos')
        const minimalOrderData = {
          order_number: orderNumber,
          customer_name: formData.name,
          customer_phone: formData.phone,
          customer_email: user?.email || null,
          products: cart.map(item => ({
            name: item.name,
            image: item.image || null,
            price: item.on_sale && item.sale_price ? item.sale_price : item.price,
            quantity: item.quantity
          })),
          total: parseFloat(total.toFixed(2))
        }
        
        const { error: minimalError } = await supabase
          .from('orders')
          .insert([minimalOrderData])
        
        if (minimalError) {
          logger.error('ERRO também com campos mínimos', minimalError)
          
          alert(`❌ ERRO: Não foi possível salvar o pedido no banco!\n\nErro: ${orderError.message}\n\nPor favor, entre em contato conosco.`)
          setLoading(false)
          return // NÃO continuar se não conseguir salvar
        } else {
          logger.success('Pedido salvo com campos mínimos')
        }
      } else {
        logger.success('Pedido salvo no banco com sucesso')
      }
      
      // Track compra no Google Analytics
      if (typeof window !== 'undefined') {
        import('@/lib/analytics').then(({ trackPurchase, trackWhatsAppClick }) => {
          trackPurchase(orderNumber, total, cart.length)
          trackWhatsAppClick('checkout')
        })
      }
      
      // Preparar mensagem WhatsApp
      const message = formatWhatsAppMessage()
      const whatsappNumber = '5555991288464'
      const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${message}`
      
      // Limpar carrinho APENAS após salvar com sucesso
      clearCart()
      
      // Abrir WhatsApp
      window.open(whatsappUrl, '_blank')
      
      // Redirecionar para página de confirmação
      setTimeout(() => {
        router.push('/pedido-confirmado')
      }, 1000)
      
    } catch (error) {
      console.error('Erro ao processar pedido:', error)
      alert('Ocorreu um erro ao processar o pedido. Tente novamente.')
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <ShoppingCart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Carrinho Vazio</h2>
          <p className="text-gray-600 mb-6">Adicione produtos ao carrinho antes de finalizar o pedido.</p>
          <button
            onClick={() => router.push('/produtos')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Ver Produtos
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Finalizar Pedido</h1>
          <p className="text-gray-600">Complete seus dados e envie o pedido via WhatsApp</p>
          <p className="text-sm text-gray-500 mt-2">Pagamento e entrega serão combinados diretamente pelo WhatsApp</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulário */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                <User className="h-5 w-5 mr-2" />
                Seus Dados
              </h2>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Nome Completo *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="Seu nome completo"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                    Telefone/WhatsApp *
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    required
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="(55) 99999-9999"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Usaremos este número para entrar em contato sobre seu pedido
                  </p>
                </div>

                <div>
                  <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">
                    Observações (Opcional)
                  </label>
                  <textarea
                    id="notes"
                    name="notes"
                    rows={4}
                    value={formData.notes}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="Alguma informação adicional sobre seu pedido? Ex: preferência de horário, endereço para entrega, etc."
                  />
                </div>
              </div>

              <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>ℹ️ Como funciona:</strong><br />
                  1. Você envia o pedido pelo WhatsApp<br />
                  2. Confirmamos disponibilidade dos produtos<br />
                  3. Combinamos forma de pagamento e entrega<br />
                  4. Pronto! Simples e rápido 🎉
                </p>
              </div>
            </div>
          </div>

          {/* Resumo do Pedido */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-4">
              <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                <Package className="h-5 w-5 mr-2" />
                Resumo do Pedido
              </h2>

              <div className="space-y-4 mb-6">
                {cart.map((item) => (
                  <div key={item.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-12 h-12 rounded object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium text-gray-900 truncate">{item.name}</h4>
                      <p className="text-xs text-gray-500">Qtd: {item.quantity}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">
                        R$ {(() => {
                          const priceToUse = item.on_sale && item.sale_price ? item.sale_price : item.price
                          const priceStr = typeof priceToUse === 'string' ? priceToUse : String(priceToUse)
                          const price = parseFloat(priceStr.replace(/[^\d.,]/g, '').replace(',', '.'))
                          return isNaN(price) ? '0,00' : formatPriceForDisplay(price * item.quantity)
                        })()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal:</span>
                  <span className="text-gray-900">R$ {formatPriceForDisplay(calculateSubtotal())}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Frete:</span>
                  <span className="text-gray-900">A combinar</span>
                </div>
                <div className="flex justify-between text-lg font-semibold border-t pt-2">
                  <span>Total:</span>
                  <span>R$ {formatPriceForDisplay(calculateTotal())} + frete</span>
                </div>
              </div>

              <button
                onClick={handleWhatsAppSubmit}
                disabled={loading || !formData.name || !formData.phone}
                className="w-full mt-6 bg-green-600 text-white py-4 px-4 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center text-lg font-semibold shadow-lg"
              >
                {loading ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Abrindo WhatsApp...
                  </div>
                ) : (
                  <>
                    <MessageCircle className="h-6 w-6 mr-2" />
                    Finalizar no WhatsApp
                  </>
                )}
              </button>

              <p className="text-xs text-gray-500 mt-4 text-center">
                Você será redirecionado para o WhatsApp com seu pedido pronto
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
