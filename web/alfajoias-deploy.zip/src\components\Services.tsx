'use client'

import { Wrench, Battery, Settings, Shield, Clock, Award } from 'lucide-react'
import { useSupabaseServices } from '@/hooks/useSupabaseServices'

export default function Services() {
  const { services, loading } = useSupabaseServices()

  const getServiceIcon = (title: string) => {
    switch (title) {
      case 'Manutenção de Relógios':
        return Wrench
      case 'Ajustes de Óculos':
        return Settings
      case 'Garantia Estendida':
        return Shield
      case 'Serviço Rápido':
        return Clock
      case 'Qualidade Garantida':
        return Award
      case 'Troca de Bateria':
        return Battery
      default:
        return Wrench
    }
  }

  return (
    <section className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-light text-gray-900 mb-6 tracking-wide">
            Nossos Serviços
          </h2>
          <div className="w-20 h-0.5 bg-gray-800 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed font-light">
            Oferecemos serviços especializados para manter seus produtos sempre em perfeito estado
          </p>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-800 mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando serviços...</p>
          </div>
        ) : services.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Wrench className="h-8 w-8 text-gray-400" />
            </div>
            <p className="text-gray-500 text-lg font-light">Nenhum serviço cadastrado no banco de dados.</p>
            <p className="text-sm text-gray-400 mt-2">Adicione serviços pelo painel administrativo.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
            const IconComponent = getServiceIcon(service.title)
            return (
              <div
                key={service.id}
                className="bg-white border border-gray-200 hover:border-gray-800 transition-all duration-300 p-8 hover:shadow-lg hover:-translate-y-2 active:scale-95"
              >
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <IconComponent className="h-8 w-8 text-gray-800" />
                </div>

                <h3 className="text-xl font-medium text-gray-900 mb-4 text-center">
                  {service.title}
                </h3>

                <p className="text-gray-600 mb-6 text-center font-light">
                  {service.description}
                </p>

                <ul className="space-y-3 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-3 text-sm text-gray-600">
                      <div className="w-2 h-2 bg-gray-800 rounded-full"></div>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <a
                  href={`https://wa.me/5555991288464?text=${encodeURIComponent(service.whatsapp_message)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-gray-800 hover:bg-gray-900 text-white px-6 py-3 rounded-lg font-medium transition-all duration-300 flex items-center justify-center space-x-2 hover:scale-105 active:scale-95"
                >
                  <span>Solicitar Serviço</span>
                </a>
              </div>
              )
            })}
          </div>
        )}

        {!loading && services.length > 0 && (
          <div className="text-center mt-16">
          <div className="bg-gray-50 border border-gray-200 p-12 max-w-4xl mx-auto">
            <h3 className="text-2xl font-light text-gray-900 mb-4">
              Precisa de um serviço específico?
            </h3>
            <p className="text-lg text-gray-600 mb-8 font-light">
              Entre em contato conosco e solicite um orçamento personalizado
            </p>
            <a
              href={`https://wa.me/5555991288464?text=${encodeURIComponent(`Olá! Gostaria de solicitar um orçamento para serviços na Alfa Jóias.

Podem me ajudar com informações sobre os serviços disponíveis?`)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center border border-gray-800 text-gray-800 hover:bg-gray-800 hover:text-white px-8 py-3 transition-all duration-300 font-medium hover:scale-105 active:scale-95"
            >
              <span>Solicitar Orçamento</span>
              <Wrench className="h-5 w-5 ml-2 transition-transform duration-300 group-hover:rotate-12" />
            </a>
          </div>
        </div>
        )}
      </div>
    </section>
  )
}