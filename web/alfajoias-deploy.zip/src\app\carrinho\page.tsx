'use client'

import { useUnifiedAuth } from '@/contexts/UnifiedAuthContext'
import Link from 'next/link'
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft, MessageCircle } from 'lucide-react'

export default function Cart() {
  const { cart, updateQuantity, removeFromCart, clearCart, isLoggedIn } = useUnifiedAuth()

  // Função para formatar preço para exibição (sempre vírgula para decimais)
  const formatPriceForDisplay = (price: string | number): string => {
    if (typeof price === 'number') {
      return price.toFixed(2).replace('.', ',')
    }
    // Limpar caracteres especiais e converter vírgula para ponto
    const cleaned = price.toString().replace(/[^\d.,]/g, '').replace(',', '.')
    const num = parseFloat(cleaned)
    if (isNaN(num)) return '0,00'
    return num.toFixed(2).replace('.', ',')
  }

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <ShoppingBag className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Faça login para acessar o carrinho</h1>
          <p className="text-gray-600 mb-6">Você precisa estar logado para adicionar produtos ao carrinho.</p>
          <Link
            href="/login"
            className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
          >
            Fazer Login
          </Link>
        </div>
      </div>
    )
  }

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <ShoppingBag className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Seu carrinho está vazio</h1>
            <p className="text-gray-600 mb-6">Adicione alguns produtos para começar suas compras.</p>
            <Link
              href="/produtos"
              className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Ver Produtos
            </Link>
          </div>
        </div>
      </div>
    )
  }

  // Calcular total do carrinho
  const calculateCartTotal = () => {
    return cart.reduce((sum, item) => {
      // Usar sale_price se estiver em promoção, senão usar price
      const priceToUse = item.on_sale && item.sale_price ? item.sale_price : item.price
      const priceStr = typeof priceToUse === 'string' ? priceToUse : String(priceToUse)
      const price = parseFloat(priceStr.replace(/[^\d.,]/g, '').replace(',', '.'))
      return sum + (isNaN(price) ? 0 : price * item.quantity)
    }, 0)
  }

  const total = calculateCartTotal()

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-8">
          <Link href="/produtos" className="flex items-center text-gray-600 hover:text-gray-800 transition-colors mr-4">
            <ArrowLeft className="h-5 w-5 mr-2" />
            Continuar comprando
          </Link>
        </div>

        <h1 className="text-3xl font-bold text-gray-900 mb-8">Carrinho de Compras</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-semibold text-gray-900">
                    Produtos ({cart.length})
                  </h2>
                  <button
                    onClick={clearCart}
                    className="text-sm text-red-600 hover:text-red-700"
                  >
                    Limpar carrinho
                  </button>
                </div>

                <div className="space-y-4">
                  {cart.map((item) => (
                    <div key={item.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{item.name}</h3>
                        {item.on_sale && item.sale_price ? (
                          <div className="flex items-center gap-2">
                            <p className="text-sm text-gray-400 line-through">
                              R$ {formatPriceForDisplay(item.original_price || item.price)}
                            </p>
                            <p className="text-sm font-semibold text-green-600">
                              R$ {formatPriceForDisplay(item.sale_price)}
                            </p>
                            {item.discount_percentage && (
                              <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">
                                -{item.discount_percentage}%
                              </span>
                            )}
                          </div>
                        ) : (
                          <p className="text-sm text-gray-600">
                            R$ {formatPriceForDisplay(item.price)}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 rounded-full hover:bg-gray-100"
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 rounded-full hover:bg-gray-100"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>

                      <div className="text-right">
                        <p className="font-semibold text-gray-900">
                          R$ {(() => {
                            const priceToUse = item.on_sale && item.sale_price ? item.sale_price : item.price
                            const priceStr = typeof priceToUse === 'string' ? priceToUse : String(priceToUse)
                            const price = parseFloat(priceStr.replace(/[^\d.,]/g, '').replace(',', '.'))
                            return isNaN(price) ? '0,00' : (price * item.quantity).toFixed(2).replace('.', ',')
                          })()}
                        </p>
                      </div>

                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Resumo do Pedido</h3>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total:</span>
                  <span className="text-lg font-bold text-gray-900">
                    R$ {total.toFixed(2).replace('.', ',')}
                  </span>
                </div>
              </div>

              <div className="space-y-3">
                <Link
                  href="/checkout"
                  className="w-full bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
                >
                  <MessageCircle className="h-5 w-5" />
                  <span>Finalizar Pedido</span>
                </Link>
              </div>

              <p className="text-xs text-gray-500 mt-4 text-center">
                Preencha seus dados e envie o pedido via WhatsApp
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

