'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Eye, Settings, Plus, Edit, Trash2, Save, X, Image, Percent, Star, Package, Truck, CheckCircle, Clock, DollarSign, Shield, Lock } from 'lucide-react'
import { useUnifiedAuth } from '@/contexts/UnifiedAuthContext'
import ImageUpload from '@/components/ImageUpload'
import BrandSelector from '@/components/BrandSelector'
import { useOrders } from '@/hooks/useOrders'
import { useSupabaseServices } from '@/hooks/useSupabaseServices'
import { useSupabaseProducts } from '@/hooks/useSupabaseProducts'
import { useBrands } from '@/hooks/useBrands'
import { useBanners } from '@/hooks/useBanners'
import { useSupabaseCategories } from '@/hooks/useSupabaseCategories'
import WhatsAppNotification from '@/components/WhatsAppNotification'
// import { formatPrice } from '@/lib/priceUtils' // Removido para evitar conflito
import { clearCacheAndReload, resetToDefaults } from '@/lib/clearCache'

interface Product {
  id: string
  name: string
  category: string
  brand: string
  price: string
  image: string
  description: string
  detailedDescription?: string
  additionalImages?: string[]
  features?: string[]
  specifications?: { [key: string]: string }
  rating?: number
  reviews?: number
  featured?: boolean
  on_sale?: boolean
  original_price?: string
  discount_percentage?: number
  sale_price?: string
  stock?: number
  inStock?: boolean
  specialPromotion?: boolean
  specialPromotionText?: string
  gender?: string
  model?: string
}

interface Service {
  id: string
  title: string
  description: string
  features: string[]
  whatsapp_message: string
}

interface Banner {
  id: string
  title: string
  subtitle: string
  image: string
  cta_text: string
  cta_link: string
  active: boolean
  created_at?: string
  updated_at?: string
}

interface Brand {
  id: string
  name: string
  image: string
  active?: boolean
}

// Função helper para formatar preços
const formatPrice = (price: string | number): string => {
  if (typeof price === 'number') {
    return price.toFixed(2).replace('.', ',')
  }
  // Se for string, limpar e converter
  const cleaned = price.toString().replace(/[^\d.,]/g, '').replace(',', '.')
  const num = parseFloat(cleaned)
  return isNaN(num) ? '0,00' : num.toFixed(2).replace('.', ',')
}

export default function Admin() {
  const router = useRouter()
  const { user, loading: authLoading, isAdmin } = useUnifiedAuth()
  const [activeTab, setActiveTab] = useState<'products' | 'services' | 'banners' | 'brands' | 'categories' | 'orders'>('products')
  const [editingCategory, setEditingCategory] = useState<any>(null)
  const [showCategoryForm, setShowCategoryForm] = useState(false)
  const [products, setProducts] = useState<Product[]>([])
  const { services, addService, updateService, deleteService } = useSupabaseServices()
  const { banners, addBanner, updateBanner, deleteBanner } = useBanners()
  const [categories, setCategories] = useState<any[]>([])
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [editingService, setEditingService] = useState<Service | null>(null)
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null)
  const [editingBrand, setEditingBrand] = useState<Brand | null>(null)
  const [showProductForm, setShowProductForm] = useState(false)
  const [showServiceForm, setShowServiceForm] = useState(false)
  const [showBannerForm, setShowBannerForm] = useState(false)
  const [showBrandForm, setShowBrandForm] = useState(false)
  const [brandImage, setBrandImage] = useState('')
  const [selectedBrand, setSelectedBrand] = useState('')
  
  // Controlar estado do checkbox de promoção especial
  useEffect(() => {
    if (showProductForm) {
      const onSaleCheckbox = document.querySelector('input[name="on_sale"]') as HTMLInputElement
      const specialPromotionCheckbox = document.querySelector('input[name="specialPromotion"]') as HTMLInputElement
      
      if (onSaleCheckbox && specialPromotionCheckbox) {
        // Configurar estado inicial
        specialPromotionCheckbox.disabled = !onSaleCheckbox.checked
        
        // Se não está em promoção, desmarcar promoção especial
        if (!onSaleCheckbox.checked) {
          specialPromotionCheckbox.checked = false
          const specialPromotionFields = document.getElementById('specialPromotionFields')
          if (specialPromotionFields) {
            specialPromotionFields.classList.add('hidden')
            specialPromotionFields.classList.remove('block')
          }
        }
      }
    }
  }, [showProductForm, editingProduct])
  const [selectedOrder, setSelectedOrder] = useState<any>(null)
  const [showOrderDetails, setShowOrderDetails] = useState(false)
  const [showWhatsAppNotification, setShowWhatsAppNotification] = useState(false)

  // Verificar acesso de admin
  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        console.log('❌ Usuário não logado, redirecionando para login...')
        router.push('/login')
      } else if (!isAdmin) {
        console.log('❌ Usuário não é admin, redirecionando para conta...')
        router.push('/conta')
      }
    }
  }, [user, isAdmin, authLoading, router])
  
  // Hook para pedidos
  const { orders, loading: ordersLoading, updateOrderStatus, addTrackingNumber } = useOrders()
  
  // Hook para produtos do Supabase
  const { products: supabaseProducts, loading: supabaseLoading, addProduct: addSupabaseProduct, updateProduct: updateSupabaseProduct, deleteProduct: deleteSupabaseProduct } = useSupabaseProducts()
  
  // Hook para marcas do Supabase
  const { brands, loading: brandsLoading, addBrand, updateBrand, deleteBrand } = useBrands()
  
  // Hook para categorias do Supabase
  const { categories: supabaseCategories, loading: categoriesLoading, addCategory, updateCategory, deleteCategory } = useSupabaseCategories()

  useEffect(() => {
    // SEMPRE usar APENAS Supabase - sem fallback
    if (!supabaseLoading) {
      if (supabaseProducts && supabaseProducts.length > 0) {
        setProducts(supabaseProducts)
        console.log('✅ Produtos carregados do BANCO:', supabaseProducts.length, 'produtos')
        console.log('⭐ Produtos em destaque:', supabaseProducts.filter(p => p.featured).length)
        console.log('🏷️ Produtos em promoção:', supabaseProducts.filter(p => p.on_sale).length)
      } else {
        console.log('⚠️ Nenhum produto no banco de dados')
        setProducts([])
      }
    }
  }, [supabaseProducts, supabaseLoading])

  useEffect(() => {
    // USAR CATEGORIAS DO SUPABASE
    if (!categoriesLoading) {
      if (supabaseCategories && supabaseCategories.length > 0) {
        setCategories(supabaseCategories)
        console.log('✅ Categorias carregadas do BANCO:', supabaseCategories.length, 'categorias')
      } else {
        console.log('⚠️ Nenhuma categoria no banco de dados')
        setCategories([])
      }
    }
  }, [supabaseCategories, categoriesLoading])

  const saveToStorage = (key: string, data: any) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(key, JSON.stringify(data))
      // Disparar evento customizado para notificar outras páginas
      window.dispatchEvent(new CustomEvent('dataUpdated', { 
        detail: { key, data } 
      }))
    }
  }

  const updateCategoryImage = (categoryId: string, newImageUrl: string) => {
    const updatedCategories = categories.map(cat => 
      cat.id === categoryId ? { ...cat, image: newImageUrl } : cat
    )
    setCategories(updatedCategories)
    saveToStorage('alfajoias-categories-images', updatedCategories)
  }

  // Função para normalizar preços (remover formatação e converter para número)
  const normalizePrice = (price: string): string => {
    if (!price) return '0'
    // Remove tudo exceto dígitos, pontos e vírgulas
    const cleaned = price.replace(/[^\d.,]/g, '')
    // Se tem vírgula, substituir por ponto (formato BR -> US)
    const normalized = cleaned.replace(',', '.')
    // Converter para número e voltar para string
    const num = parseFloat(normalized)
    return isNaN(num) ? '0' : num.toString()
  }

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    
    const stock = Math.max(1, parseInt(formData.get('stock') as string) || 1)
    const productData = {
      name: formData.get('name') as string,
      category: formData.get('category') as string,
      brand: selectedBrand || formData.get('brand') as string,
      price: normalizePrice(formData.get('price') as string),
      image: formData.get('image') as string,
      description: formData.get('description') as string,
      featured: formData.get('featured') === 'on',
      on_sale: formData.get('on_sale') === 'on',
      original_price: normalizePrice(formData.get('original_price') as string || ''),
      discount_percentage: parseInt(formData.get('discount_percentage') as string) || 0,
      sale_price: normalizePrice(formData.get('sale_price') as string || ''),
      gender: formData.get('gender') as string || '',
      model: formData.get('model') as string || '',
    }

    // Validação de dados
    const validation = await import('@/lib/validation').then(m => m.validateProductData(productData))
    if (!validation.valid) {
      alert('Erros de validação:\n' + validation.errors.join('\n'))
      return
    }

    try {
      if (editingProduct) {
        // Atualizar produto APENAS no Supabase
        await updateSupabaseProduct(editingProduct.id, productData)
        console.log('✅ Produto atualizado no BANCO:', productData)
        alert('✅ Produto atualizado com sucesso no banco de dados!')
      } else {
        // Adicionar produto APENAS no Supabase
        await addSupabaseProduct(productData)
        console.log('✅ Produto adicionado no BANCO:', productData)
        alert('✅ Produto adicionado com sucesso ao banco de dados!')
      }
      
      setEditingProduct(null)
      setShowProductForm(false)
      setSelectedBrand('')
      
    } catch (error: any) {
      console.error('❌ Erro ao salvar produto no banco:', error)
      alert(`❌ ERRO AO SALVAR NO BANCO DE DADOS\n\n${error?.message || 'Erro desconhecido'}\n\n💡 Verifique:\n• Configuração do Supabase\n• Conexão com a internet\n• Permissões no banco`)
    }
  }

  const handleServiceSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    
    const serviceData = {
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      features: formData.get('features')?.toString().split('\n').filter(f => f.trim()) || [],
      whatsapp_message: formData.get('whatsappMessage') as string,
    }

    try {
      if (editingService) {
        await updateService(editingService.id, serviceData)
      } else {
        await addService(serviceData)
      }
      setEditingService(null)
      setShowServiceForm(false)
    } catch (error) {
      console.error('Erro ao salvar serviço:', error)
      alert('Erro ao salvar serviço. Tente novamente.')
    }
  }

  const handleBannerSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    console.log('🔄 ========== SALVANDO BANNER ==========')
    
    try {
      const formData = new FormData(e.target as HTMLFormElement)
      
      const bannerData = {
        title: formData.get('title') as string,
        subtitle: formData.get('subtitle') as string,
        image: formData.get('image') as string,
        cta_text: formData.get('ctaText') as string,
        cta_link: formData.get('ctaLink') as string,
        active: formData.get('active') === 'on',
      }

      console.log('📝 Dados do banner:', bannerData)

      if (editingBanner) {
        console.log('✏️ Modo: EDITAR banner')
        await updateBanner(editingBanner.id, bannerData)
      } else {
        console.log('➕ Modo: ADICIONAR banner')
        await addBanner(bannerData)
      }
      
      console.log('✅ Banner salvo com sucesso!')
      
      setEditingBanner(null)
      setShowBannerForm(false)
      
    } catch (error) {
      console.error('❌ Erro ao salvar banner:', error)
      alert(`Erro ao salvar banner: ${error instanceof Error ? error.message : 'Erro desconhecido'}`)
    }
  }

  const handleBrandSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    console.log('🔄 ========== INICIANDO SALVAMENTO ==========')
    
    try {
      const formData = new FormData(e.target as HTMLFormElement)
      
      const brandData = {
        name: formData.get('name') as string,
        image: formData.get('image') as string || brandImage,
        // Removido 'active' - coluna não existe no banco
      }

      console.log('📝 Dados extraídos do formulário:', brandData)
      
      // Validar dados básicos
      if (!brandData.name || brandData.name.trim() === '') {
        alert('Nome da marca é obrigatório!')
        return
      }

      if (editingBrand) {
        console.log('✏️ Modo: EDITAR marca existente')
        await updateBrand(editingBrand.id, brandData)
      } else {
        console.log('➕ Modo: ADICIONAR nova marca')
        await addBrand(brandData)
      }
      
      console.log('✅ Operação concluída com sucesso!')
      
      // Fechar formulário
      setEditingBrand(null)
      setShowBrandForm(false)
      setBrandImage('')
      
      console.log('🎉 Formulário fechado - SUCESSO TOTAL!')
      
    } catch (error) {
      console.error('❌ ========== ERRO CAPTURADO ==========')
      console.error('❌ Tipo do erro:', typeof error)
      console.error('❌ Mensagem:', error instanceof Error ? error.message : String(error))
      console.error('❌ Stack:', error instanceof Error ? error.stack : 'N/A')
      
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido'
      alert(`ERRO: ${errorMessage}`)
    }
  }

  const handleCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    
    const categoryData = {
      name: formData.get('name') as string,
      description: formData.get('description') as string,
      image: formData.get('image') as string,
      icon: formData.get('icon') as string
    }

    try {
      if (editingCategory) {
        await updateCategory(editingCategory.id, categoryData)
        console.log('✅ Categoria atualizada no BANCO:', categoryData)
      } else {
        await addCategory(categoryData)
        console.log('✅ Categoria adicionada no BANCO:', categoryData)
      }
      
      setEditingCategory(null)
      setShowCategoryForm(false)
    } catch (error) {
      console.error('❌ Erro ao salvar categoria no banco:', error)
      alert(`❌ ERRO AO SALVAR NO BANCO DE DADOS\n\n${error instanceof Error ? error.message : 'Erro desconhecido'}\n\n💡 Verifique:\n• Configuração do Supabase\n• Conexão com a internet\n• Permissões no banco`)
    }
  }

  const deleteItem = async (type: string, id: string) => {
    if (!confirm('Tem certeza que deseja excluir este item?')) {
      return
    }
    
    switch (type) {
      case 'product':
        try {
          // Deletar APENAS do Supabase
          await deleteSupabaseProduct(id)
          console.log('✅ Produto deletado do BANCO:', id)
          alert('✅ Produto excluído com sucesso do banco de dados!')
        } catch (error: any) {
          console.error('❌ Erro ao deletar produto do banco:', error)
          alert(`❌ ERRO AO DELETAR DO BANCO\n\n${error?.message || 'Erro desconhecido'}\n\nVerifique a conexão com o Supabase.`)
        }
        break
      case 'service':
        try {
          await deleteService(id)
          alert('✅ Serviço excluído com sucesso!')
        } catch (error) {
          console.error('Erro ao deletar serviço:', error)
          alert('❌ Erro ao deletar serviço. Tente novamente.')
        }
        break
      case 'banner':
        try {
          await deleteBanner(id)
          console.log('✅ Banner deletado do banco:', id)
          alert('✅ Banner excluído com sucesso do banco de dados!')
        } catch (error) {
          console.error('❌ Erro ao deletar banner:', error)
          alert('❌ Erro ao deletar banner. Tente novamente.')
        }
        break
      case 'brand':
        try {
          await deleteBrand(id)
          console.log('✅ Marca deletada do banco:', id)
          alert('✅ Marca excluída com sucesso do banco de dados!')
        } catch (error) {
          console.error('❌ Erro ao deletar marca:', error)
          alert('❌ Erro ao deletar marca. Tente novamente.')
        }
        break
      case 'category':
        try {
          await deleteCategory(id)
          console.log('✅ Categoria deletada do banco:', id)
          alert('✅ Categoria excluída com sucesso do banco de dados!')
        } catch (error) {
          console.error('❌ Erro ao deletar categoria do banco:', error)
          alert('❌ Erro ao deletar categoria. Tente novamente.')
        }
        break
    }
  }

  // APENAS 4 categorias permitidas
  const productCategories = ['Joias', 'Relógios', 'Óculos', 'Semi-Joias']
  
  // Função para categorias iniciais
  const initialCategoriesData = () => [
    {
      id: '1',
      name: 'Joias',
      description: 'Anéis, colares, brincos e pulseiras em ouro e prata',
      image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&h=600&fit=crop',
      icon: 'gem',
      href: '/produtos?categoria=Joias'
    },
    {
      id: '2',
      name: 'Relógios',
      description: 'Relógios masculinos e femininos das melhores marcas',
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&h=600&fit=crop',
      icon: 'clock',
      href: '/produtos?categoria=Relógios'
    },
    {
      id: '3',
      name: 'Óculos',
      description: 'Óculos de sol e grau com tecnologia avançada',
      image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&h=600&fit=crop',
      icon: 'eye',
      href: '/produtos?categoria=Óculos'
    },
    {
      id: '4',
      name: 'Semi-Joias',
      description: 'Bijuterias elegantes e acessórios modernos',
      image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&h=600&fit=crop',
      icon: 'diamond',
      href: '/produtos?categoria=Semi-Joias'
    }
  ]

  // Mostrar loading enquanto verifica autenticação
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Verificando acesso...</p>
        </div>
      </div>
    )
  }

  // Verificar se tem acesso
  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Lock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Acesso Negado</h1>
          <p className="text-gray-600 mb-6">Você precisa estar logado para acessar esta página.</p>
          <a
            href="/login"
            className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
          >
            Fazer Login
          </a>
        </div>
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Shield className="h-16 w-16 text-red-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Acesso Restrito</h1>
          <p className="text-gray-600 mb-6">Apenas administradores podem acessar esta página.</p>
          <div className="space-x-4">
            <a
              href="/conta"
              className="bg-gray-600 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Minha Conta
            </a>
            <a
              href="/"
              className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Voltar ao Site
            </a>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Settings className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Painel Administrativo</h1>
                <p className="text-gray-600">Gerencie produtos, serviços, banners e marcas</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Eye className="h-4 w-4" />
                <span>Visualizar site</span>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={clearCacheAndReload}
                  className="px-3 py-1 text-xs bg-yellow-100 text-yellow-800 rounded hover:bg-yellow-200"
                  title="Limpar cache e recarregar dados"
                >
                  🔄 Atualizar
                </button>
                <button
                  onClick={() => {
                    if (confirm('Tem certeza? Isso irá resetar TODOS os dados para o padrão!')) {
                      resetToDefaults()
                    }
                  }}
                  className="px-3 py-1 text-xs bg-red-100 text-red-800 rounded hover:bg-red-200"
                  title="Resetar todos os dados"
                >
                  ⚠️ Reset
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8 px-6">
              {[
                { id: 'products', name: 'Produtos', count: products.length },
                { id: 'services', name: 'Serviços', count: services.length },
                { id: 'banners', name: 'Banners', count: banners.length },
                { id: 'brands', name: 'Marcas', count: brands.length },
                { id: 'categories', name: 'Categorias', count: categories.length },
                { id: 'orders', name: 'Pedidos', count: orders.length },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.name} ({tab.count})
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Content */}
        <div className="bg-white rounded-lg shadow-sm">
          {/* Products Tab */}
          {activeTab === 'products' && (
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Produtos</h2>
                <button
                  onClick={() => setShowProductForm(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Produto
                </button>
                
                <button
                  onClick={() => {
                    // Forçar sincronização dos dados
                    window.location.reload()
                  }}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 ml-2"
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Sincronizar Dados
                </button>
              </div>

              {supabaseLoading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                  <p className="text-gray-600">Carregando produtos do banco de dados...</p>
                </div>
              ) : products.length === 0 ? (
                <div className="text-center py-16 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                  <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-medium text-gray-900 mb-2">Nenhum produto no banco de dados</h3>
                  <p className="text-gray-600 mb-6 max-w-md mx-auto">
                    Comece adicionando seu primeiro produto no banco de dados clicando no botão abaixo.
                  </p>
                  <button
                    onClick={() => setShowProductForm(true)}
                    className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                  >
                    <Plus className="h-5 w-5 mr-2" />
                    Adicionar Primeiro Produto
                  </button>
                </div>
              ) : (
                <>
                  {/* Indicador de conexão com banco */}
                  <div className="col-span-full mb-4">
                    <div className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      ✅ Conectado ao Banco de Dados ({products.length} produtos)
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {products.map((product) => (
                      <div key={product.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <img src={product.image} alt={product.name} className="w-full h-48 object-cover rounded-lg mb-4" />
                        <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
                        <p className="text-sm text-gray-600 mb-2">{product.brand} - {product.category}</p>
                        <p className="text-lg font-bold text-blue-600 mb-4">{formatPrice(product.price)}</p>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => {
                              setEditingProduct(product)
                              setShowProductForm(true)
                            }}
                            className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                          >
                            <Edit className="h-4 w-4 mr-1" />
                            Editar
                          </button>
                          <button
                            onClick={() => deleteItem('product', product.id)}
                            className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-red-300 text-sm font-medium rounded-md text-red-700 bg-white hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Excluir
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Services Tab */}
          {activeTab === 'services' && (
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Serviços</h2>
                <button
                  onClick={() => setShowServiceForm(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Serviço
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {services.map((service) => (
                  <div key={service.id} className="border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">{service.title}</h3>
                    <p className="text-gray-600 mb-4">{service.description}</p>
                    
                    {/* Features */}
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Características:</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        {service.features.map((feature, index) => (
                          <li key={index} className="flex items-center">
                            <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* WhatsApp Message Preview */}
                    <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                      <h4 className="text-sm font-medium text-green-800 mb-2">Mensagem do WhatsApp:</h4>
                      <p className="text-sm text-green-700">{service.whatsapp_message}</p>
                    </div>

                    <div className="flex space-x-2">
                      <button
                        onClick={() => {
                          setEditingService(service)
                          setShowServiceForm(true)
                        }}
                        className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Editar
                      </button>
                      <button
                        onClick={() => deleteItem('service', service.id)}
                        className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-red-300 text-sm font-medium rounded-md text-red-700 bg-white hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Excluir
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Banners Tab */}
          {activeTab === 'banners' && (
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Banners do Hero</h2>
                <button
                  onClick={() => setShowBannerForm(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Banner
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {banners.map((banner) => (
                  <div key={banner.id} className="border border-gray-200 rounded-lg overflow-hidden">
                    <img src={banner.image} alt={banner.title} className="w-full h-48 object-cover" />
                    <div className="p-4">
                      <h3 className="font-semibold text-gray-900 mb-2">{banner.title}</h3>
                      <p className="text-gray-600 mb-4">{banner.subtitle}</p>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => {
                            setEditingBanner(banner)
                            setShowBannerForm(true)
                          }}
                          className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Editar
                        </button>
                        <button
                          onClick={() => deleteItem('banner', banner.id)}
                          className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-red-300 text-sm font-medium rounded-md text-red-700 bg-white hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Excluir
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Brands Tab */}
          {activeTab === 'brands' && (
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Marcas</h2>
                <button
                  onClick={() => setShowBrandForm(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Marca
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {brands.map((brand) => (
                  <div key={brand.id} className="border border-gray-200 rounded-lg p-4">
                    {brand.image && (
                      <img src={brand.image} alt={brand.name} className="w-full h-32 object-contain mb-4" />
                    )}
                    <h3 className="font-semibold text-gray-900 mb-2">{brand.name}</h3>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => {
                          setEditingBrand(brand)
                          setShowBrandForm(true)
                        }}
                        className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Editar
                      </button>
                      <button
                        onClick={() => deleteItem('brand', brand.id)}
                        className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-red-300 text-sm font-medium rounded-md text-red-700 bg-white hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Excluir
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Categories Tab */}
          {activeTab === 'categories' && (
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Categorias</h2>
                <button
                  onClick={() => setShowCategoryForm(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Categoria
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {categories.map((category) => (
                  <div key={category.id} className="border border-gray-200 rounded-lg p-4">
                    <img src={category.image} alt={category.name} className="w-full h-48 object-cover rounded-lg mb-4" />
                    <h3 className="font-semibold text-gray-900 mb-2">{category.name}</h3>
                    <p className="text-sm text-gray-600 mb-4">{category.description}</p>
                    
                    {/* Configurações de Filtro */}
                    <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Configurações de Filtro</h4>
                      <div className="space-y-2">
                        <div className="text-xs text-gray-600">
                          <strong>URL do Filtro:</strong> {category.href || '/produtos'}
                        </div>
                        <div className="text-xs text-gray-600">
                          <strong>Ícone:</strong> {category.icon || 'gem'}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2">
                      <button
                        onClick={() => {
                          setEditingCategory(category)
                          setShowCategoryForm(true)
                        }}
                        className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Editar
                      </button>
                      <button
                        onClick={() => deleteItem('category', category.id)}
                        className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-red-300 text-sm font-medium rounded-md text-red-700 bg-white hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Excluir
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Orders Tab */}
          {activeTab === 'orders' && (
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Pedidos</h2>
                <div className="text-sm text-gray-500">
                  {orders.length} pedido(s) encontrado(s)
                </div>
              </div>

              {ordersLoading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                  <p className="text-gray-600">Carregando pedidos...</p>
                </div>
              ) : orders.length === 0 ? (
                <div className="text-center py-12">
                  <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Nenhum pedido encontrado</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <div key={order.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">
                            Pedido #{order.order_number}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {new Date(order.created_at).toLocaleDateString('pt-BR')} às{' '}
                            {new Date(order.created_at).toLocaleTimeString('pt-BR', { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            order.status === 'pending_whatsapp' ? 'bg-yellow-100 text-yellow-800' :
                            order.status === 'confirmed' ? 'bg-blue-100 text-blue-800' :
                            order.status === 'ready' ? 'bg-purple-100 text-purple-800' :
                            order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                            order.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {order.status === 'pending_whatsapp' ? 'Aguardando WhatsApp' :
                             order.status === 'confirmed' ? 'Confirmado' :
                             order.status === 'ready' ? 'Pronto' :
                             order.status === 'delivered' ? 'Entregue' :
                             order.status === 'cancelled' ? 'Cancelado' :
                             order.status}
                          </span>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            order.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                            order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {order.status === 'confirmed' ? 'Confirmado' :
                             order.status === 'pending' ? 'Pendente' :
                             order.status || 'Desconhecido'}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                        {/* Produtos */}
                        <div>
                          <h4 className="font-medium text-gray-900 mb-2">Produtos</h4>
                          <div className="space-y-2">
                            {order.products.map((product: any, index: number) => (
                              <div key={index} className="flex items-center space-x-3">
                                {product.image ? (
                                  <img 
                                    src={product.image} 
                                    alt={product.name}
                                    className="w-10 h-10 rounded object-cover"
                                  />
                                ) : (
                                  <div className="w-10 h-10 rounded bg-gray-200 flex items-center justify-center">
                                    <Package className="h-5 w-5 text-gray-400" />
                                  </div>
                                )}
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-medium text-gray-900 truncate">
                                    {product.name}
                                  </p>
                                  <p className="text-xs text-gray-500">
                                    Qtd: {product.quantity} • R$ {formatPrice(product.price)}
                                  </p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Cliente */}
                        <div>
                          <h4 className="font-medium text-gray-900 mb-2">Cliente</h4>
                          <div className="text-sm text-gray-600">
                            <p className="font-medium">{order.customer_name || 'Nome não informado'}</p>
                            <p>{order.customer_phone || 'Telefone não informado'}</p>
                            {order.customer_email && (
                              <p className="text-xs text-gray-500">{order.customer_email}</p>
                            )}
                            {order.notes && (
                              <p className="text-xs text-gray-500 mt-2">
                                <strong>Observações:</strong> {order.notes}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Resumo Financeiro */}
                        <div>
                          <h4 className="font-medium text-gray-900 mb-2">Resumo</h4>
                          <div className="text-sm text-gray-600 space-y-1">
                            <div className="flex justify-between">
                              <span>Subtotal:</span>
                              <span>R$ {formatPrice(order.subtotal)}</span>
                            </div>
                            {order.shipping && (typeof order.shipping === 'number' ? order.shipping > 0 : parseFloat(order.shipping.toString()) > 0) && (
                              <div className="flex justify-between">
                                <span>Frete:</span>
                                <span>R$ {formatPrice(order.shipping)}</span>
                              </div>
                            )}
                            {order.discount && (typeof order.discount === 'number' ? order.discount > 0 : parseFloat(order.discount.toString()) > 0) && (
                              <div className="flex justify-between text-green-600">
                                <span>Desconto:</span>
                                <span>-R$ {formatPrice(order.discount)}</span>
                              </div>
                            )}
                            <div className="flex justify-between font-medium border-t pt-1">
                              <span>Total:</span>
                              <span>R$ {formatPrice(order.total)}</span>
                            </div>
                            <p className="text-xs text-gray-500 mt-2">
                              Status: {order.status || 'Pendente'}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Ações */}
                      <div className="flex justify-between items-center pt-4 border-t">
                        <div className="flex items-center space-x-4">
                          {order.tracking_number && (
                            <div className="flex items-center space-x-2 text-sm text-gray-600">
                              <Truck className="h-4 w-4" />
                              <span>Rastreamento: {order.tracking_number}</span>
                            </div>
                          )}
                          {order.shipped_at && (
                            <div className="flex items-center space-x-2 text-sm text-gray-600">
                              <CheckCircle className="h-4 w-4" />
                              <span>Enviado em: {new Date(order.shipped_at).toLocaleDateString('pt-BR')}</span>
                            </div>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => {
                              setSelectedOrder(order)
                              setShowOrderDetails(true)
                            }}
                            className="px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                          >
                            Ver Detalhes
                          </button>
                          
                          <button
                            onClick={() => {
                              setSelectedOrder(order)
                              setShowWhatsAppNotification(true)
                            }}
                            className="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-md hover:bg-green-700"
                          >
                            WhatsApp
                          </button>
                          
                          {order.status === 'pending_whatsapp' && (
                            <button
                              onClick={() => updateOrderStatus(order.id, 'confirmed')}
                              className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700"
                            >
                              Confirmar Pedido
                            </button>
                          )}
                          
                          {order.status === 'confirmed' && (
                            <button
                              onClick={() => updateOrderStatus(order.id, 'ready')}
                              className="px-4 py-2 bg-purple-600 text-white text-sm font-medium rounded-md hover:bg-purple-700"
                            >
                              Marcar como Pronto
                            </button>
                          )}
                          
                          {order.status === 'ready' && (
                            <button
                              onClick={() => updateOrderStatus(order.id, 'delivered')}
                              className="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-md hover:bg-green-700"
                            >
                              Marcar como Entregue
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Product Form Modal */}
      {showProductForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 max-w-2xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                {editingProduct ? 'Editar Produto' : 'Adicionar Produto'}
              </h3>
              <button
                onClick={() => {
                  setShowProductForm(false)
                  setEditingProduct(null)
                  setSelectedBrand('')
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <form onSubmit={handleProductSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Nome</label>
                  <input
                    type="text"
                    name="name"
                    defaultValue={editingProduct?.name || ''}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Categoria</label>
                  <select
                    name="category"
                    defaultValue={editingProduct?.category || ''}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                  >
                    <option value="">Selecione uma categoria</option>
                    {productCategories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Marca</label>
                  <BrandSelector
                    value={editingProduct?.brand || selectedBrand}
                    onChange={setSelectedBrand}
                    brands={brands}
                    placeholder="Selecione uma marca (opcional)"
                  />
                  <input type="hidden" name="brand" value={selectedBrand} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Preço</label>
                  <input
                    type="text"
                    name="price"
                    defaultValue={editingProduct?.price || ''}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Gênero</label>
                  <select
                    name="gender"
                    defaultValue={editingProduct?.gender || ''}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                  >
                    <option value="">Selecione o gênero</option>
                    <option value="Masculino">Masculino</option>
                    <option value="Feminino">Feminino</option>
                    <option value="Unissex">Unissex</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Modelo</label>
                  <input
                    type="text"
                    name="model"
                    defaultValue={editingProduct?.model || ''}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                    placeholder="Ex: Clássico, Moderno, Esportivo"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Imagem do Produto</label>
                <ImageUpload
                  onImageSelect={(imageUrl) => {
                    const input = document.querySelector('input[name="image"]') as HTMLInputElement
                    if (input) input.value = imageUrl
                  }}
                  currentImage={editingProduct?.image}
                  placeholder="Selecione uma imagem para o produto"
                />
                <input
                  type="hidden"
                  name="image"
                  defaultValue={editingProduct?.image || ''}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Descrição (opcional)</label>
                <textarea
                  name="description"
                  defaultValue={editingProduct?.description || ''}
                  rows={3}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                  placeholder="Descrição do produto (opcional)"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Estoque *</label>
                  <input
                    type="number"
                    name="stock"
                    defaultValue={editingProduct?.stock || 1}
                    min="1"
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                    placeholder="Quantidade em estoque (mínimo: 1)"
                  />
                </div>
                <div className="flex items-center space-x-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="featured"
                      defaultChecked={editingProduct?.featured || false}
                      className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                    <span className="ml-2 text-sm text-gray-700">Produto em destaque</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="on_sale"
                      defaultChecked={editingProduct?.on_sale || false}
                      onChange={(e) => {
                        const promotionFields = document.getElementById('promotionFields')
                        const specialPromotionCheckbox = document.querySelector('input[name="specialPromotion"]') as HTMLInputElement
                        const specialPromotionFields = document.getElementById('specialPromotionFields')
                        
                        if (promotionFields) {
                          if (e.target.checked) {
                            promotionFields.classList.remove('hidden')
                            promotionFields.classList.add('block')
                            // Habilitar checkbox de promoção especial
                            if (specialPromotionCheckbox) {
                              specialPromotionCheckbox.disabled = false
                            }
                          } else {
                            promotionFields.classList.add('hidden')
                            promotionFields.classList.remove('block')
                            // Desabilitar e desmarcar promoção especial
                            if (specialPromotionCheckbox) {
                              specialPromotionCheckbox.disabled = true
                              specialPromotionCheckbox.checked = false
                            }
                            if (specialPromotionFields) {
                              specialPromotionFields.classList.add('hidden')
                              specialPromotionFields.classList.remove('block')
                            }
                          }
                        }
                      }}
                      className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                    />
                    <span className="ml-2 text-sm text-gray-700">Em promoção</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="specialPromotion"
                      defaultChecked={editingProduct?.specialPromotion || false}
                      disabled={!editingProduct?.on_sale}
                      onChange={(e) => {
                        const specialPromotionFields = document.getElementById('specialPromotionFields')
                        if (specialPromotionFields) {
                          if (e.target.checked) {
                            specialPromotionFields.classList.remove('hidden')
                            specialPromotionFields.classList.add('block')
                          } else {
                            specialPromotionFields.classList.add('hidden')
                            specialPromotionFields.classList.remove('block')
                          }
                        }
                      }}
                      className="rounded border-gray-300 text-purple-600 shadow-sm focus:border-purple-300 focus:ring focus:ring-purple-200 focus:ring-opacity-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    />
                    <span className="ml-2 text-sm text-gray-700">Promoção especial</span>
                    <span className="ml-1 text-xs text-gray-500">(requer &quot;Em promoção&quot;)</span>
                  </label>
                </div>
              </div>

              {/* Campos de Promoção - Aparecem apenas quando "Em promoção" está marcado */}
              <div id="promotionFields" className={editingProduct?.on_sale ? 'block' : 'hidden'}>
                <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
                  <h4 className="text-sm font-medium text-yellow-800 mb-3">Configurações de Promoção</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Preço Original</label>
                      <input
                        type="text"
                        name="original_price"
                        defaultValue={editingProduct?.original_price || ''}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                        placeholder="R$ 1.200,00"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">% de Desconto</label>
                      <input
                        type="number"
                        name="discount_percentage"
                        defaultValue={editingProduct?.discount_percentage || ''}
                        min="1"
                        max="99"
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                        placeholder="20"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Preço Promocional</label>
                      <input
                        type="text"
                        name="sale_price"
                        defaultValue={editingProduct?.sale_price || ''}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                        placeholder="R$ 960,00"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Campos de Promoção Especial - Aparecem apenas quando "Promoção especial" está marcado E "Em promoção" está ativo */}
              <div id="specialPromotionFields" className={editingProduct?.specialPromotion && editingProduct?.on_sale ? 'block' : 'hidden'}>
                <div className="bg-purple-50 border border-purple-200 rounded-md p-4">
                  <h4 className="text-sm font-medium text-purple-800 mb-3">Configurações de Promoção Especial</h4>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Texto da Promoção Especial</label>
                      <input
                        type="text"
                        name="specialPromotionText"
                        defaultValue={editingProduct?.specialPromotionText || ''}
                        className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                        placeholder="Ex: Black Friday, Liquidação, Oferta Limitada"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Este texto aparecerá como destaque especial no produto
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowProductForm(false)
                    setEditingProduct(null)
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Save className="h-4 w-4 mr-2 inline" />
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Banner Form Modal */}
      {showBannerForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 max-w-2xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                {editingBanner ? 'Editar Banner' : 'Adicionar Banner'}
              </h3>
              <button
                onClick={() => {
                  setShowBannerForm(false)
                  setEditingBanner(null)
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <form onSubmit={handleBannerSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Título</label>
                <input
                  type="text"
                  name="title"
                  defaultValue={editingBanner?.title || ''}
                  required
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Subtítulo</label>
                <input
                  type="text"
                  name="subtitle"
                  defaultValue={editingBanner?.subtitle || ''}
                  required
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Imagem do Banner</label>
                <ImageUpload
                  onImageSelect={(imageUrl) => {
                    const input = document.querySelector('input[name="image"]') as HTMLInputElement
                    if (input) input.value = imageUrl
                  }}
                  currentImage={editingBanner?.image}
                  placeholder="Selecione uma imagem para o banner"
                />
                <input
                  type="hidden"
                  name="image"
                  defaultValue={editingBanner?.image || ''}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Texto do Botão</label>
                  <input
                    type="text"
                    name="ctaText"
                    defaultValue={editingBanner?.cta_text || ''}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Link do Botão</label>
                  <input
                    type="text"
                    name="ctaLink"
                    defaultValue={editingBanner?.cta_link || ''}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                </div>
              </div>

              <div className="flex items-center">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    name="active"
                    defaultChecked={editingBanner?.active || false}
                    className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                  />
                  <span className="ml-2 text-sm text-gray-700">Banner ativo</span>
                </label>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowBannerForm(false)
                    setEditingBanner(null)
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Save className="h-4 w-4 mr-2 inline" />
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Service Form Modal */}
      {showServiceForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 max-w-2xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                {editingService ? 'Editar Serviço' : 'Adicionar Serviço'}
              </h3>
              <button
                onClick={() => {
                  setShowServiceForm(false)
                  setEditingService(null)
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <form onSubmit={handleServiceSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Título</label>
                <input
                  type="text"
                  name="title"
                  defaultValue={editingService?.title || ''}
                  required
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Descrição</label>
                <textarea
                  name="description"
                  defaultValue={editingService?.description || ''}
                  required
                  rows={4}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Características (uma por linha)</label>
                <textarea
                  name="features"
                  defaultValue={editingService?.features?.join('\n') || ''}
                  rows={4}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Mensagem do WhatsApp</label>
                <textarea
                  name="whatsapp_message"
                  defaultValue={editingService?.whatsapp_message || ''}
                  rows={3}
                  placeholder="Ex: Olá! Gostaria de solicitar informações sobre [nome do serviço]. Podem me ajudar?"
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                />
                <p className="mt-1 text-sm text-gray-500">Esta mensagem será enviada automaticamente quando o cliente clicar no botão do WhatsApp</p>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowServiceForm(false)
                    setEditingService(null)
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Save className="h-4 w-4 mr-2 inline" />
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Brand Form Modal */}
      {showBrandForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 max-w-2xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                {editingBrand ? 'Editar Marca' : 'Adicionar Marca'}
              </h3>
              <button
                onClick={() => {
                  setShowBrandForm(false)
                  setEditingBrand(null)
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <form onSubmit={handleBrandSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Nome da Marca</label>
                <input
                  type="text"
                  name="name"
                  defaultValue={editingBrand?.name || ''}
                  required
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                />
              </div>


              <div>
                <label className="block text-sm font-medium text-gray-700">Logo da Marca</label>
                <ImageUpload
                  onImageSelect={(image) => setBrandImage(image)}
                  currentImage={editingBrand?.image || brandImage}
                  placeholder="Selecione o logo da marca"
                />
                <input type="hidden" name="image" value={brandImage} />
              </div>

              <div className="flex items-center">
                {/* Campo 'active' removido - coluna não existe no banco */}
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowBrandForm(false)
                    setEditingBrand(null)
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Save className="h-4 w-4 mr-2 inline" />
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Category Form Modal */}
      {showCategoryForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 max-w-2xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-900">
                {editingCategory ? 'Editar Categoria' : 'Adicionar Categoria'}
              </h3>
              <button
                onClick={() => {
                  setShowCategoryForm(false)
                  setEditingCategory(null)
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <form onSubmit={handleCategorySubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Nome da Categoria</label>
                <input
                  type="text"
                  name="name"
                  defaultValue={editingCategory?.name || ''}
                  required
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Descrição</label>
                <textarea
                  name="description"
                  defaultValue={editingCategory?.description || ''}
                  rows={3}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Imagem da Categoria</label>
                <ImageUpload
                  onImageSelect={(imageUrl) => {
                    const input = document.querySelector('input[name="image"]') as HTMLInputElement
                    if (input) input.value = imageUrl
                  }}
                  currentImage={editingCategory?.image}
                  placeholder="Selecione uma imagem para a categoria"
                />
                <input
                  type="hidden"
                  name="image"
                  defaultValue={editingCategory?.image || ''}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Ícone</label>
                <select
                  name="icon"
                  defaultValue={editingCategory?.icon || 'gem'}
                  required
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                >
                  <option value="gem">💎 Gem (Joias)</option>
                  <option value="clock">⌚ Clock (Relógios)</option>
                  <option value="eye">👓 Eye (Óculos)</option>
                  <option value="diamond">💍 Diamond (Semi-Joias)</option>
                </select>
              </div>

              {/* Configurações de Filtro */}
              <div className="bg-gray-50 border border-gray-200 rounded-md p-4">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Configurações de Filtro</h4>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700">URL do Filtro</label>
                  <input
                    type="text"
                    name="href"
                    defaultValue={editingCategory?.href || ''}
                    placeholder="/produtos?categoria=Joias"
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    URL que será chamada quando a categoria for clicada
                  </p>
                </div>

                <div className="mt-3">
                  <label className="block text-sm font-medium text-gray-700">Nome para Filtro</label>
                  <input
                    type="text"
                    name="filterName"
                    defaultValue={editingCategory?.filterName || editingCategory?.name || ''}
                    placeholder="Joias"
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Nome usado para filtrar produtos (deve corresponder ao campo &quot;categoria&quot; dos produtos)
                  </p>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowCategoryForm(false)
                    setEditingCategory(null)
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Save className="h-4 w-4 mr-2 inline" />
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Order Details Modal */}
      {showOrderDetails && selectedOrder && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 max-w-4xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-gray-900">
                Detalhes do Pedido #{selectedOrder.order_number}
              </h3>
              <button
                onClick={() => {
                  setShowOrderDetails(false)
                  setSelectedOrder(null)
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Informações do Cliente */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Informações do Cliente</h4>
                <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Nome:</label>
                    <p className="text-gray-900">{selectedOrder.customer_name || 'Nome não informado'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Telefone:</label>
                    <p className="text-gray-900">{selectedOrder.customer_phone || 'Telefone não informado'}</p>
                  </div>
                  {selectedOrder.customer_email && (
                    <div>
                      <label className="text-sm font-medium text-gray-600">Email:</label>
                      <p className="text-gray-900">{selectedOrder.customer_email}</p>
                    </div>
                  )}
                  {selectedOrder.notes && (
                    <div>
                      <label className="text-sm font-medium text-gray-600">Observações:</label>
                      <p className="text-gray-900">{selectedOrder.notes}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Resumo do Pedido */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Resumo do Pedido</h4>
                <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      selectedOrder.status === 'pending_whatsapp' ? 'bg-yellow-100 text-yellow-800' :
                      selectedOrder.status === 'confirmed' ? 'bg-blue-100 text-blue-800' :
                      selectedOrder.status === 'ready' ? 'bg-purple-100 text-purple-800' :
                      selectedOrder.status === 'delivered' ? 'bg-green-100 text-green-800' :
                      selectedOrder.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {selectedOrder.status === 'pending_whatsapp' ? 'Aguardando WhatsApp' :
                       selectedOrder.status === 'confirmed' ? 'Confirmado' :
                       selectedOrder.status === 'ready' ? 'Pronto' :
                       selectedOrder.status === 'delivered' ? 'Entregue' :
                       selectedOrder.status === 'cancelled' ? 'Cancelado' :
                       selectedOrder.status}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Pagamento:</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      selectedOrder.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                      selectedOrder.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {selectedOrder.status === 'confirmed' ? 'Confirmado' :
                       selectedOrder.status === 'pending' ? 'Pendente' :
                       selectedOrder.status || 'Desconhecido'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <span className="text-gray-900">{selectedOrder.status || 'Pendente'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Data do Pedido:</span>
                    <span className="text-gray-900">
                      {new Date(selectedOrder.created_at).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                  {selectedOrder.shipped_at && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Data de Envio:</span>
                      <span className="text-gray-900">
                        {new Date(selectedOrder.shipped_at).toLocaleDateString('pt-BR')}
                      </span>
                    </div>
                  )}
                  {selectedOrder.delivered_at && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Data de Entrega:</span>
                      <span className="text-gray-900">
                        {new Date(selectedOrder.delivered_at).toLocaleDateString('pt-BR')}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Produtos do Pedido */}
            <div className="mt-8">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Produtos</h4>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="space-y-4">
                  {selectedOrder.products.map((product: any, index: number) => (
                    <div key={index} className="flex items-center space-x-4 p-3 bg-white rounded border">
                      {product.image ? (
                        <img 
                          src={product.image} 
                          alt={product.name}
                          className="w-16 h-16 rounded object-cover"
                        />
                      ) : (
                        <div className="w-16 h-16 rounded bg-gray-200 flex items-center justify-center">
                          <Package className="h-8 w-8 text-gray-400" />
                        </div>
                      )}
                      <div className="flex-1">
                        <h5 className="font-medium text-gray-900">{product.name}</h5>
                        <p className="text-sm text-gray-600">Quantidade: {product.quantity}</p>
                        <p className="text-sm text-gray-600">
                          Preço unitário: R$ {formatPrice(product.price)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-gray-900">
                          R$ {formatPrice(typeof product.price === 'number' ? product.price * product.quantity : parseFloat(product.price.toString()) * product.quantity)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Resumo Financeiro */}
                <div className="mt-6 pt-4 border-t">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Subtotal:</span>
                      <span className="text-gray-900">R$ {formatPrice(selectedOrder.subtotal)}</span>
                    </div>
                    {selectedOrder.shipping && (typeof selectedOrder.shipping === 'number' ? selectedOrder.shipping > 0 : parseFloat(selectedOrder.shipping.toString()) > 0) && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Frete:</span>
                        <span className="text-gray-900">R$ {formatPrice(selectedOrder.shipping)}</span>
                      </div>
                    )}
                    {selectedOrder.discount && (typeof selectedOrder.discount === 'number' ? selectedOrder.discount > 0 : parseFloat(selectedOrder.discount.toString()) > 0) && (
                      <div className="flex justify-between text-green-600">
                        <span>Desconto:</span>
                        <span>-R$ {formatPrice(selectedOrder.discount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-medium text-lg border-t pt-2">
                      <span>Total:</span>
                      <span>R$ {formatPrice(selectedOrder.total)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Ações */}
            <div className="mt-8 flex justify-end space-x-4">
              <button
                onClick={() => {
                  setShowOrderDetails(false)
                  setSelectedOrder(null)
                }}
                className="px-6 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                Fechar
              </button>
              
              {selectedOrder.status === 'pending_whatsapp' && (
                <button
                  onClick={() => {
                    updateOrderStatus(selectedOrder.id, 'confirmed')
                    setShowOrderDetails(false)
                  }}
                  className="px-6 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700"
                >
                  Confirmar Pedido
                </button>
              )}
              
              {selectedOrder.status === 'confirmed' && (
                <button
                  onClick={() => {
                    updateOrderStatus(selectedOrder.id, 'ready')
                    setShowOrderDetails(false)
                  }}
                  className="px-6 py-2 bg-purple-600 text-white text-sm font-medium rounded-md hover:bg-purple-700"
                >
                  Marcar como Pronto
                </button>
              )}
              
              {selectedOrder.status === 'ready' && (
                <button
                  onClick={() => {
                    updateOrderStatus(selectedOrder.id, 'delivered')
                    setShowOrderDetails(false)
                  }}
                  className="px-6 py-2 bg-green-600 text-white text-sm font-medium rounded-md hover:bg-green-700"
                >
                  Marcar como Entregue
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* WhatsApp Notification Modal */}
      {showWhatsAppNotification && selectedOrder && (
        <WhatsAppNotification
          order={selectedOrder}
          onClose={() => {
            setShowWhatsAppNotification(false)
            setSelectedOrder(null)
          }}
        />
      )}
    </div>
  )
}